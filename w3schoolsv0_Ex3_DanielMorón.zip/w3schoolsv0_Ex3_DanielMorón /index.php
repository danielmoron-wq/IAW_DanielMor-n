<?php
require_once 'session.php';
redirectIfNotLoggedIn();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestión de Base de Datos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>📊 Sistema de Gestión de Base de Datos</h1>
            <div class="user-info">
                <p>Usuario: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'admin'); ?></strong></p>
                <button onclick="showLogoutConfirmation()" class="btn-logout">🚪 Cerrar Sesión</button>
            </div>
        </header>
        
        <main>
            <h2>Operaciones Disponibles</h2>
            
            <div class="operations-grid">
                <div class="operation-category">
                    <h3>📁 Base de Datos</h3>
                    <ol>
                        <li><a href="db_connect.php">Conectar</a></li>
                        <li><a href="db_create.php">Crear la base de datos</a></li>
                        <li><a href="db_drop.php">Borrar la base de datos</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>📊 Tablas</h3>
                    <ol start="4">
                        <li><a href="table_create_guests.php">Crear tabla MyGuests</a></li>
                        <li><a href="table_check_exists.php">Verificar existencia de tabla</a></li>
                        <li><a href="table_drop.php">Borrar tabla MyGuests</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>➕ Insertar Datos</h3>
                    <ol start="7">
                        <li><a href="data_insert_single.php">Insertar datos (registro único)</a></li>
                        <li><a href="data_insert_single_get_last_id.php">Insertar y obtener último ID</a></li>
                        <li><a href="data_insert_multiple_simple.php">Insertar múltiples datos (simple)</a></li>
                        <li><a href="data_insert_multiple_prepared.php">Insertar múltiples datos (preparado)</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>👁️ Consultar Datos</h3>
                    <ol start="11">
                        <li><a href="data_count.php">Contar registros</a></li>
                        <li><a href="data_select_all.php">Visualizar todos los datos</a></li>
                        <li><a href="data_select_where.php">Visualizar datos (WHERE)</a></li>
                        <li><a href="data_select_orderby.php">Visualizar datos (ORDER BY)</a></li>
                        <li><a href="data_select_where_orderby_html_table.php">Visualizar en tabla HTML</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>✏️ Modificar Datos</h3>
                    <ol start="16">
                        <li><a href="data_delete.php">Borrar usuario id=3</a></li>
                        <li><a href="data_update.php">Actualizar usuario id=2</a></li>
                    </ol>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Modal de confirmación de logout -->
    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <h2>¿Estás seguro?</h2>
            <p>¿Realmente deseas cerrar sesión en el sistema?</p>
            <div class="modal-buttons">
                <button onclick="hideLogoutConfirmation()" class="btn-cancel">Cancelar</button>
                <a href="logout_confirmation.php" class="btn-confirm">Sí, cerrar sesión</a>
            </div>
        </div>
    </div>
    
    <script>
        function showLogoutConfirmation() {
            document.getElementById('logoutModal').style.display = 'flex';
        }
        
        function hideLogoutConfirmation() {
            document.getElementById('logoutModal').style.display = 'none';
        }
        
        // Cerrar modal al hacer clic fuera
        window.onclick = function(event) {
            const modal = document.getElementById('logoutModal');
            if (event.target === modal) {
                hideLogoutConfirmation();
            }
        }
    </script>
</body>
</html>
