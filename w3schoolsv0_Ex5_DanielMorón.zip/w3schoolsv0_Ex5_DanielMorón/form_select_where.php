<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$resultados = [];
$lastname = recoge('lastname');
$mostrar_resultados = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    validarCampoNoVacio($lastname, "Apellido", $errores);
    
    if (empty($errores)) {
        $conn = conectarBD();
        
        $sql = "SELECT id, firstname, lastname, email, telefono, codigousuario 
                FROM MyGuests 
                WHERE lastname = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $lastname);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if ($result) {
            $resultados = mysqli_fetch_all($result, MYSQLI_ASSOC);
            $mostrar_resultados = true;
        } else {
            $errores[] = "Error en la consulta: " . mysqli_error($conn);
        }
        
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    }
}

// INCLUIR CABECERA BOOTSTRAP
include("cabecera.php");
?>

<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-search"></i> Buscar por Apellido</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-search"></i> Buscar por Apellido</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <?php include("funciones.php"); mostrarErrores($errores); ?>
                
                <div class="mb-3">
                    <label for="lastname" class="form-label">Apellido a buscar *</label>
                    <input type="text" class="form-control" id="lastname" name="lastname" 
                           value="<?php echo htmlspecialchars($lastname); ?>"
                           required minlength="2" maxlength="30">
                    <div class="form-text">Introduce el apellido que deseas buscar</div>
                </div>
                
                <div class="d-grid gap-2 d-md-flex">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i> Buscar
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Volver
                    </a>
                </div>
            </form>
            
            <?php if ($mostrar_resultados): ?>
                <hr class="my-4">
                <h5 class="mb-3">
                    <i class="bi bi-list-check"></i> Resultados para "<?php echo htmlspecialchars($lastname); ?>"
                </h5>
                
                <?php if (empty($resultados)): ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> No se encontraron registros con el apellido "<?php echo htmlspecialchars($lastname); ?>".
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th>Email</th>
                                    <th>Teléfono</th>
                                    <th>Código Usuario</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($resultados as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['firstname']); ?></td>
                                        <td><?php echo htmlspecialchars($row['lastname']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                                        <td><?php echo htmlspecialchars($row['codigousuario']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle"></i> Se encontraron <?php echo count($resultados); ?> registro(s).
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// INCLUIR PIE DE PÁGINA
include("pie.php");
?>