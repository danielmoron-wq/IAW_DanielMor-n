<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$resultados = [];
$order_by_raw = recoge('order_by');
$order_by = in_array($order_by_raw, ['ASC', 'DESC']) ? $order_by_raw : 'ASC';
$mostrar_resultados = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = conectarBD();
    
    $sql = "SELECT id, firstname, lastname, email, telefono, codigousuario 
            FROM MyGuests 
            ORDER BY lastname $order_by, firstname $order_by";
    
    $result = mysqli_query($conn, $sql);
    
    if ($result) {
        $resultados = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $mostrar_resultados = true;
    } else {
        $errores[] = "Error en la consulta: " . mysqli_error($conn);
    }
    
    mysqli_close($conn);
}

// INCLUIR CABECERA BOOTSTRAP
include("cabecera.php");
?>

<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-sort-alpha-down"></i> Visualizar Ordenados</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-sort-alpha-down"></i> Visualizar Registros Ordenados</h5>
        </div>
        <div class="card-body">
            <?php include("funciones.php"); mostrarErrores($errores); ?>
            
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="order_by" class="form-label">Ordenar por:</label>
                        <select class="form-select" id="order_by" name="order_by">
                            <option value="ASC" <?php echo $order_by === 'ASC' ? 'selected' : ''; ?>>
                                <i class="bi bi-sort-up"></i> Ascendente (A-Z)
                            </option>
                            <option value="DESC" <?php echo $order_by === 'DESC' ? 'selected' : ''; ?>>
                                <i class="bi bi-sort-down"></i> Descendente (Z-A)
                            </option>
                        </select>
                        <div class="form-text">Se ordenará por apellido y luego por nombre</div>
                    </div>
                </div>
                
                <div class="mt-4 d-grid gap-2 d-md-flex">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-table"></i> Mostrar Registros
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Volver
                    </a>
                </div>
            </form>
            
            <?php if ($mostrar_resultados): ?>
                <hr class="my-4">
                <h5 class="mb-3">
                    <i class="bi bi-list-check"></i> Registros ordenados 
                    <?php echo $order_by === 'ASC' ? 'ascendentemente (A-Z)' : 'descendentemente (Z-A)'; ?>
                </h5>
                
                <?php if (empty($resultados)): ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> No hay registros en la base de datos.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th>Email</th>
                                    <th>Teléfono</th>
                                    <th>Código Usuario</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($resultados as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['firstname']); ?></td>
                                        <td><?php echo htmlspecialchars($row['lastname']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                                        <td><?php echo htmlspecialchars($row['codigousuario']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle"></i> Total de registros: <?php echo count($resultados); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// INCLUIR PIE DE PÁGINA
include("pie.php");
?>