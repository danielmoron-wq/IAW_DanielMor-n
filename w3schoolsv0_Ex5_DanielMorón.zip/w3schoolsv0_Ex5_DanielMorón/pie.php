    <!-- Footer -->
    <footer class="footer mt-auto py-3 bg-light border-top">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <span class="text-muted">
                        <i class="bi bi-c-circle"></i> <?php echo date('Y'); ?> - Sistema de Gestión de Base de Datos
                    </span>
                </div>
                <div class="col-md-6 text-end">
                    <span class="text-muted">
                        Usuario: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'admin'); ?></strong>
                    </span>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>