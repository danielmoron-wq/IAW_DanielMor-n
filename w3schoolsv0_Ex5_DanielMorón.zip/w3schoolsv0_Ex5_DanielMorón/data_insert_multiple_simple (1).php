 <?php
$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bd_w3_dml2";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully<br>";

// Prepare the multiple query
$sql = "INSERT INTO MyGuests (firstname, lastname, email, telefono, codigousuario)
VALUES ('John', 'Doe', 'john@example.com', '698547320', 'u97416');";
$sql .= "INSERT INTO MyGuests (firstname, lastname, email, telefono, codigousuario)
VALUES ('Mary', 'Moe', 'mary@example.com', '6510322870', 'u44160');";
$sql .= "INSERT INTO MyGuests (firstname, lastname, email, telefono, codigousuario)
VALUES ('Julie', 'Dooley', 'julie@example.com', '607882981', 'u10647')";

if (mysqli_multi_query($conn, $sql)) {
  echo "New records created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);
?> 
