<?php
require_once 'session.php';
redirectIfNotLoggedIn();

// Si se confirma el logout
if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    logout();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmar Cierre de Sesión</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="logout-container">
        <div class="confirmation-box">
            <h2>⚠️ Confirmar Cierre de Sesión</h2>
            <p>¿Estás seguro de que deseas cerrar sesión en el sistema?</p>
            <p>Serás redirigido a la página de login.</p>
            
            <div class="confirmation-buttons">
                <a href="index.php" class="btn-cancel">No, volver al sistema</a>
                <a href="logout.php" class="btn-confirm">Sí, cerrar sesión</a>
            </div>
        </div>
    </div>
</body>
</html>