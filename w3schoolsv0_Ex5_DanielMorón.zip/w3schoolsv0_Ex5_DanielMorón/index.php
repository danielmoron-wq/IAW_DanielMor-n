<?php
require_once 'session.php';
redirectIfNotLoggedIn();

// Incluir cabecera completa
include("cabecera.php");
?>

    <!-- Contenido Principal -->
    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center py-5">
                        <h1 class="display-4 mb-3">📊 Sistema de Gestión de Base de Datos</h1>
                        <p class="lead text-muted mb-4">
                            Bienvenido al sistema de gestión de base de datos MySQL con interfaz web
                        </p>
                        <div class="alert alert-info d-inline-block">
                            <i class="bi bi-info-circle me-2"></i>
                            Usuario conectado: <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <h2 class="mb-4">🚀 Acciones Rápidas</h2>
        
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            
            <!-- Tarjeta Formularios -->
            <div class="col">
                <div class="card h-100 border-primary">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-file-earmark-text text-primary"></i> Formularios
                        </h5>
                        <p class="card-text">Formularios interactivos para gestionar los datos</p>
                        <ul class="list-unstyled">
                            <li><a href="form_insert.php" class="text-decoration-none">➕ Insertar Registro</a></li>
                            <li><a href="form_select_where.php" class="text-decoration-none">🔍 Buscar por Apellido</a></li>
                            <li><a href="form_select_order.php" class="text-decoration-none">📈 Visualizar Ordenados</a></li>
                            <li><a href="form_delete.php" class="text-decoration-none">🗑️ Eliminar Registro</a></li>
                            <li><a href="form_update.php" class="text-decoration-none">✏️ Actualizar Apellido</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Base de Datos -->
            <div class="col">
                <div class="card h-100 border-success">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-server text-success"></i> Base de Datos
                        </h5>
                        <p class="card-text">Operaciones con la base de datos</p>
                        <ul class="list-unstyled">
                            <li><a href="db_connect.php" class="text-decoration-none">🔌 Conectar</a></li>
                            <li><a href="db_create.php" class="text-decoration-none">🆕 Crear BD</a></li>
                            <li><a href="db_drop.php" class="text-decoration-none">🗑️ Borrar BD</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Tablas -->
            <div class="col">
                <div class="card h-100 border-warning">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-table text-warning"></i> Tablas
                        </h5>
                        <p class="card-text">Gestión de tablas en la base de datos</p>
                        <ul class="list-unstyled">
                            <li><a href="table_create_guests.php" class="text-decoration-none">📝 Crear Tabla</a></li>
                            <li><a href="table_check_exists.php" class="text-decoration-none">❓ Verificar Tabla</a></li>
                            <li><a href="table_drop.php" class="text-decoration-none">🗑️ Borrar Tabla</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Insertar Datos -->
            <div class="col">
                <div class="card h-100 border-info">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-cloud-upload text-info"></i> Insertar Datos
                        </h5>
                        <p class="card-text">Diferentes métodos para insertar datos</p>
                        <ul class="list-unstyled">
                            <li><a href="data_insert_single.php" class="text-decoration-none">👤 Registro Único</a></li>
                            <li><a href="data_insert_single_get_last_id.php" class="text-decoration-none">👤 Registro con ID</a></li>
                            <li><a href="data_insert_multiple_simple.php" class="text-decoration-none">👥 Múltiple Simple</a></li>
                            <li><a href="data_insert_multiple_prepared.php" class="text-decoration-none">👥 Múltiple Preparado</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Consultar Datos -->
            <div class="col">
                <div class="card h-100 border-secondary">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-eye text-secondary"></i> Consultar Datos
                        </h5>
                        <p class="card-text">Consultas y visualización de datos</p>
                        <ul class="list-unstyled">
                            <li><a href="data_count.php" class="text-decoration-none">🔢 Contar Registros</a></li>
                            <li><a href="data_select_all.php" class="text-decoration-none">📋 Visualizar Todos</a></li>
                            <li><a href="data_select_where.php" class="text-decoration-none">🔍 Visualizar (WHERE)</a></li>
                            <li><a href="data_select_orderby.php" class="text-decoration-none">📊 Visualizar (ORDER BY)</a></li>
                            <li><a href="data_select_where_orderby_html_table.php" class="text-decoration-none">📑 Tabla HTML</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Modificar Datos -->
            <div class="col">
                <div class="card h-100 border-danger">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-pencil text-danger"></i> Modificar Datos
                        </h5>
                        <p class="card-text">Modificación y eliminación de datos</p>
                        <ul class="list-unstyled">
                            <li><a href="data_delete.php" class="text-decoration-none">❌ Borrar Usuario</a></li>
                            <li><a href="data_update.php" class="text-decoration-none">✏️ Actualizar Usuario</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
        </div>
        
        <!-- Información del Sistema -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="card border-0 bg-light">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-info-circle"></i> Información del Sistema
                        </h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Credenciales de Acceso:</strong></p>
                                <ul>
                                    <li>Usuario: <code>admin</code></li>
                                    <li>Contraseña: <code>P4ssw0rd</code></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Base de Datos:</strong></p>
                                <ul>
                                    <li>Usuario BD: <code>dml</code></li>
                                    <li>Contraseña BD: <code>dml</code></li>
                                    <li>Nombre BD: <code>bd_w3_dml2</code></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
// Incluir pie de página
include("pie.php");
?>