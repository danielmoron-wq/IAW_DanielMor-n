<?php
require_once 'session.php';
redirectIfLoggedIn();

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit();
    } else {
        $error = 'Usuario o contraseña incorrectos';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Solo estilos básicos para login -->
    <link rel="stylesheet" href="style.css">
    <title>Login - Sistema de Gestión</title>
</head>
<body class="login-page">
    <div class="login-container fade-in">
        <div class="login-header">
            <h1><i class="bi bi-database"></i> Sistema de Gestión</h1>
            <p>Inicie sesión para acceder al sistema</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Usuario:</label>
                <input type="text" id="username" name="username" required 
                       class="form-control" placeholder="admin" autocomplete="username">
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required 
                       class="form-control" placeholder="••••••••" autocomplete="current-password">
            </div>
            
            <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-box-arrow-in-right"></i> Iniciar Sesión
            </button>
            
            <div class="mt-3 text-center">
                <p class="text-muted small">
                    <strong>Credenciales de prueba:</strong><br>
                    Usuario: <code>admin</code> | Contraseña: <code>P4ssw0rd</code>
                </p>
            </div>
        </form>
    </div>
</body>
</html>