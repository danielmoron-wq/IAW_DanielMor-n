<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$exito = false;
$id = recoge('id');
$confirmado = recoge('confirmado') === 'si';

if ($_SERVER["REQUEST_METHOD"] == "POST" && $confirmado) {
    validarID($id, $errores);
    
    if (empty($errores)) {
        $conn = conectarBD();
        
        $sql_check = "SELECT id, firstname, lastname FROM MyGuests WHERE id = ?";
        $stmt_check = mysqli_prepare($conn, $sql_check);
        mysqli_stmt_bind_param($stmt_check, "i", $id);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);
        
        if (mysqli_stmt_num_rows($stmt_check) == 0) {
            $errores[] = "No existe ningún registro con el ID $id.";
        } else {
            mysqli_stmt_bind_result($stmt_check, $id_reg, $firstname, $lastname);
            mysqli_stmt_fetch($stmt_check);
            
            $sql_delete = "DELETE FROM MyGuests WHERE id = ?";
            $stmt_delete = mysqli_prepare($conn, $sql_delete);
            mysqli_stmt_bind_param($stmt_delete, "i", $id);
            
            if (mysqli_stmt_execute($stmt_delete)) {
                if (mysqli_affected_rows($conn) > 0) {
                    $exito = true;
                    $mensaje_exito = "Registro eliminado correctamente: $firstname $lastname (ID: $id)";
                    $id = '';
                }
            } else {
                $errores[] = "Error al eliminar registro: " . mysqli_error($conn);
            }
            
            mysqli_stmt_close($stmt_delete);
        }
        
        mysqli_stmt_close($stmt_check);
        mysqli_close($conn);
    }
}

// INCLUIR CABECERA BOOTSTRAP
include("cabecera.php");
?>

<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-trash"></i> Eliminar Registro</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-danger text-white">
            <h5 class="mb-0"><i class="bi bi-trash"></i> Eliminar Registro</h5>
        </div>
        <div class="card-body">
            <?php 
            include("funciones.php");
            mostrarErrores($errores);
            if ($exito) {
                mostrarExito($mensaje_exito);
            }
            ?>
            
            <?php if (!$confirmado): ?>
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle"></i> 
                    <strong>Advertencia:</strong> Esta acción eliminará permanentemente el registro de la base de datos.
                </div>
                
                <form method="POST" action="" id="deleteForm">
                    <div class="mb-3">
                        <label for="id" class="form-label">ID del registro a eliminar *</label>
                        <input type="number" class="form-control" id="id" name="id" 
                               value="<?php echo htmlspecialchars($id); ?>"
                               required min="1" step="1">
                        <div class="form-text">Introduce el ID numérico del registro que deseas eliminar</div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex">
                        <button type="submit" name="confirmado" value="si" 
                                class="btn btn-danger" 
                                onclick="return confirm('¿Estás seguro de eliminar este registro?\\n\\nEsta acción NO se puede deshacer.')">
                            <i class="bi bi-trash"></i> Eliminar Registro
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-x-circle"></i> Cancelar
                        </a>
                    </div>
                </form>
            <?php else: ?>
                <div class="text-center py-4">
                    <div class="mb-3">
                        <i class="bi bi-check-circle text-success" style="font-size: 3rem;"></i>
                    </div>
                    <h5 class="text-success">Operación Completada</h5>
                    <p class="text-muted">El registro ha sido eliminado correctamente.</p>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-center mt-4">
                        <a href="form_delete.php" class="btn btn-primary">
                            <i class="bi bi-trash"></i> Eliminar otro registro
                        </a>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-house"></i> Volver al inicio
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle"></i> 
                Esta acción es irreversible. Asegúrate de tener el ID correcto antes de proceder.
            </div>
        </div>
    </div>
</div>

<?php
// INCLUIR PIE DE PÁGINA
include("pie.php");
?>