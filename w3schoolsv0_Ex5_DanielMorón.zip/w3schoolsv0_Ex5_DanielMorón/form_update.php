<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$exito = false;
$id = recoge('id');
$new_lastname = recoge('new_lastname');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    validarID($id, $errores);
    validarCampoNoVacio($new_lastname, "Nuevo apellido", $errores);
    
    if (empty($errores)) {
        $conn = conectarBD();
        
        $sql_check = "SELECT firstname, lastname FROM MyGuests WHERE id = ?";
        $stmt_check = mysqli_prepare($conn, $sql_check);
        mysqli_stmt_bind_param($stmt_check, "i", $id);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);
        
        if (mysqli_stmt_num_rows($stmt_check) == 0) {
            $errores[] = "No existe ningún registro con el ID $id.";
        } else {
            mysqli_stmt_bind_result($stmt_check, $current_firstname, $current_lastname);
            mysqli_stmt_fetch($stmt_check);
            
            $sql_update = "UPDATE MyGuests SET lastname = ? WHERE id = ?";
            $stmt_update = mysqli_prepare($conn, $sql_update);
            mysqli_stmt_bind_param($stmt_update, "si", $new_lastname, $id);
            
            if (mysqli_stmt_execute($stmt_update)) {
                if (mysqli_affected_rows($conn) > 0) {
                    $exito = true;
                    $mensaje_exito = "<strong>Registro actualizado correctamente:</strong><br>";
                    $mensaje_exito .= "• ID: $id<br>";
                    $mensaje_exito .= "• Nombre: $current_firstname<br>";
                    $mensaje_exito .= "• Apellido anterior: $current_lastname<br>";
                    $mensaje_exito .= "• Apellido nuevo: $new_lastname";
                    
                    $id = '';
                    $new_lastname = '';
                } else {
                    $errores[] = "No se realizaron cambios (posiblemente el nuevo apellido es igual al anterior).";
                }
            } else {
                $errores[] = "Error al actualizar registro: " . mysqli_error($conn);
            }
            
            mysqli_stmt_close($stmt_update);
        }
        
        mysqli_stmt_close($stmt_check);
        mysqli_close($conn);
    }
}

// INCLUIR CABECERA BOOTSTRAP
include("cabecera.php");
?>

<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-pencil-square"></i> Actualizar Apellido</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0"><i class="bi bi-pencil-square"></i> Actualizar Apellido</h5>
        </div>
        <div class="card-body">
            <?php 
            include("funciones.php");
            mostrarErrores($errores);
            if ($exito) {
                echo '<div class="alert alert-success">' . $mensaje_exito . '</div>';
            }
            ?>
            
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="id" class="form-label">ID del registro *</label>
                        <input type="number" class="form-control" id="id" name="id" 
                               value="<?php echo htmlspecialchars($id); ?>"
                               required min="1" step="1">
                        <div class="form-text">ID numérico del registro a actualizar</div>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="new_lastname" class="form-label">Nuevo apellido *</label>
                        <input type="text" class="form-control" id="new_lastname" name="new_lastname" 
                               value="<?php echo htmlspecialchars($new_lastname); ?>"
                               required minlength="2" maxlength="30">
                        <div class="form-text">Introduce el nuevo apellido (2-30 caracteres)</div>
                    </div>
                </div>
                
                <div class="mt-4 d-grid gap-2 d-md-flex">
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-pencil-square"></i> Actualizar Apellido
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="bi bi-arrow-clockwise"></i> Limpiar
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Volver
                    </a>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle"></i> 
                Este formulario actualizará únicamente el apellido del registro especificado.
                Se mantendrán todos los demás campos sin cambios.
            </div>
        </div>
    </div>
</div>

<?php
// INCLUIR PIE DE PÁGINA
include("pie.php");
?>