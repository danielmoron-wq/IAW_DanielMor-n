<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$exito = false;
$datos = [
    'firstname' => '',
    'lastname' => '',
    'email' => '',
    'telefono' => '',
    'codigousuario' => ''
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = recoge('firstname');
    $lastname = recoge('lastname');
    $email = recoge('email');
    $telefono = recoge('telefono');
    $codigousuario = recoge('codigousuario');
    
    validarCampoNoVacio($firstname, "Nombre", $errores);
    validarCampoNoVacio($lastname, "Apellido", $errores);
    validarCampoNoVacio($email, "Email", $errores);
    validarEmail($email, $errores);
    validarCampoNoVacio($telefono, "Teléfono", $errores);
    validarTelefono($telefono, $errores);
    validarCampoNoVacio($codigousuario, "Código de Usuario", $errores);
    validarCodigoUsuario($codigousuario, $errores);
    
    $datos = [
        'firstname' => $firstname,
        'lastname' => $lastname,
        'email' => $email,
        'telefono' => $telefono,
        'codigousuario' => $codigousuario
    ];
    
    if (empty($errores)) {
        $conn = conectarBD();
        
        $sql = "INSERT INTO MyGuests (firstname, lastname, email, telefono, codigousuario) 
                VALUES (?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssss", $firstname, $lastname, $email, $telefono, $codigousuario);
        
        if (mysqli_stmt_execute($stmt)) {
            $exito = true;
            $last_id = mysqli_insert_id($conn);
            $mensaje_exito = "Registro insertado correctamente. ID: " . $last_id;
            
            $datos = [
                'firstname' => '',
                'lastname' => '',
                'email' => '',
                'telefono' => '',
                'codigousuario' => ''
            ];
        } else {
            $errores[] = "Error al insertar registro: " . mysqli_error($conn);
        }
        
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    }
}

// INCLUIR CABECERA BOOTSTRAP
include("cabecera.php");
?>

<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-plus-circle"></i> Insertar Registro</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Insertar Nuevo Registro</h5>
        </div>
        <div class="card-body">
            <?php
            include("funciones.php");
            mostrarErrores($errores);
            if ($exito) {
                mostrarExito($mensaje_exito);
            }
            ?>
            
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="firstname" class="form-label">Nombre *</label>
                        <input type="text" class="form-control" id="firstname" name="firstname" 
                               value="<?php echo htmlspecialchars($datos['firstname']); ?>"
                               required minlength="2" maxlength="30">
                        <div class="form-text">Mínimo 2 caracteres</div>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="lastname" class="form-label">Apellido *</label>
                        <input type="text" class="form-control" id="lastname" name="lastname" 
                               value="<?php echo htmlspecialchars($datos['lastname']); ?>"
                               required minlength="2" maxlength="30">
                        <div class="form-text">Mínimo 2 caracteres</div>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email *</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?php echo htmlspecialchars($datos['email']); ?>"
                               required>
                        <div class="form-text">Formato válido: usuario@dominio.com</div>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="telefono" class="form-label">Teléfono *</label>
                        <input type="text" class="form-control" id="telefono" name="telefono" 
                               value="<?php echo htmlspecialchars($datos['telefono']); ?>"
                               required pattern="\d{9}" 
                               title="9 dígitos sin espacios">
                        <div class="form-text">9 dígitos (ej: 612345678)</div>
                    </div>
                    
                    <div class="col-md-12">
                        <label for="codigousuario" class="form-label">Código Usuario *</label>
                        <input type="text" class="form-control" id="codigousuario" name="codigousuario" 
                               value="<?php echo htmlspecialchars($datos['codigousuario']); ?>"
                               required pattern="u\d{5}" 
                               title="'u' seguido de 5 dígitos">
                        <div class="form-text">Formato: u + 5 dígitos (ej: u12345)</div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i> Insertar Registro
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="bi bi-arrow-clockwise"></i> Limpiar
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Volver al Inicio
                    </a>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle"></i> Todos los campos marcados con * son obligatorios.
            </div>
        </div>
    </div>
</div>

<?php
// INCLUIR PIE DE PÁGINA
include("pie.php");
?>