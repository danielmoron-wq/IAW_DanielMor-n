<?php
// Función para mostrar errores
function mostrarErrores($errores) {
    if (!empty($errores)) {
        echo '<div class="alert alert-error">';
        echo '<h4>Errores encontrados:</h4>';
        echo '<ul>';
        foreach ($errores as $error) {
            echo '<li>' . htmlspecialchars($error) . '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }
}

// Función para mostrar éxito
function mostrarExito($mensaje) {
    echo '<div class="alert alert-success">';
    echo htmlspecialchars($mensaje);
    echo '</div>';
}

// Función para mostrar información
function mostrarInfo($mensaje) {
    echo '<div class="alert alert-info">';
    echo htmlspecialchars($mensaje);
    echo '</div>';
}
?>