<?php
// Verificar si el usuario está logueado
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="style.css">
    <title>Sistema de Gestión de Base de Datos</title>
</head>
<body>
    <!-- Navbar Bootstrap -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-database"></i> Sistema Gestión BD
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    
                    <!-- Menú Inicio -->
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="bi bi-house"></i> Inicio
                        </a>
                    </li>
                    
                    <!-- Dropdown Formularios -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="formulariosDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-file-earmark-text"></i> Formularios
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="formulariosDropdown">
                            <li>
                                <a class="dropdown-item" href="form_insert.php">
                                    <i class="bi bi-plus-circle"></i> Insertar Registro
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="form_select_where.php">
                                    <i class="bi bi-search"></i> Buscar por Apellido
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="form_select_order.php">
                                    <i class="bi bi-sort-alpha-down"></i> Visualizar Ordenados
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="form_delete.php">
                                    <i class="bi bi-trash"></i> Eliminar Registro
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="form_update.php">
                                    <i class="bi bi-pencil-square"></i> Actualizar Apellido
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Base de Datos -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="bdDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-server"></i> Base de Datos
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="bdDropdown">
                            <li>
                                <a class="dropdown-item" href="db_connect.php">
                                    <i class="bi bi-plug"></i> Conectar
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="db_create.php">
                                    <i class="bi bi-plus-square"></i> Crear BD
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="db_drop.php">
                                    <i class="bi bi-trash"></i> Borrar BD
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Tablas -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="tablasDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-table"></i> Tablas
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="tablasDropdown">
                            <li>
                                <a class="dropdown-item" href="table_create_guests.php">
                                    <i class="bi bi-file-plus"></i> Crear Tabla
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="table_check_exists.php">
                                    <i class="bi bi-question-circle"></i> Verificar Tabla
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="table_drop.php">
                                    <i class="bi bi-file-earmark-minus"></i> Borrar Tabla
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Insertar Datos -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="insertarDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-cloud-upload"></i> Insertar Datos
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="insertarDropdown">
                            <li>
                                <a class="dropdown-item" href="data_insert_single.php">
                                    <i class="bi bi-person-plus"></i> Registro Único
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="data_insert_single_get_last_id.php">
                                    <i class="bi bi-person-plus"></i> Registro con ID
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="data_insert_multiple_simple.php">
                                    <i class="bi bi-people"></i> Múltiple Simple
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="data_insert_multiple_prepared.php">
                                    <i class="bi bi-people-fill"></i> Múltiple Preparado
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Consultar Datos -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="consultarDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-eye"></i> Consultar Datos
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="consultarDropdown">
                            <li>
                                <a class="dropdown-item" href="data_count.php">
                                    <i class="bi bi-123"></i> Contar Registros
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="data_select_all.php">
                                    <i class="bi bi-list"></i> Visualizar Todos
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="data_select_where.php">
                                    <i class="bi bi-filter"></i> Visualizar (WHERE)
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="data_select_orderby.php">
                                    <i class="bi bi-sort-down"></i> Visualizar (ORDER BY)
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="data_select_where_orderby_html_table.php">
                                    <i class="bi bi-table"></i> Tabla HTML
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Modificar Datos -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="modificarDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-pencil"></i> Modificar Datos
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="modificarDropdown">
                            <li>
                                <a class="dropdown-item" href="data_delete.php">
                                    <i class="bi bi-person-x"></i> Borrar Usuario
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="data_update.php">
                                    <i class="bi bi-person-check"></i> Actualizar Usuario
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                </ul>
                
                <!-- Usuario y Logout -->
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle"></i> 
                            <?php echo htmlspecialchars($_SESSION['username'] ?? 'Usuario'); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li>
                                <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                                    <i class="bi bi-box-arrow-right"></i> Cerrar Sesión
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Modal de Confirmación de Logout -->
    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">
                        <i class="bi bi-question-circle"></i> Confirmar Cierre de Sesión
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>¿Estás seguro de que deseas cerrar sesión en el sistema?</p>
                    <p>Serás redirigido a la página de login.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Cancelar
                    </button>
                    <a href="logout_confirmation.php" class="btn btn-danger">
                        <i class="bi bi-box-arrow-right"></i> Sí, Cerrar Sesión
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap 5 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Scripts personalizados -->
    <script>
        // Inicializar tooltips
        document.addEventListener('DOMContentLoaded', function() {
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });
    </script>