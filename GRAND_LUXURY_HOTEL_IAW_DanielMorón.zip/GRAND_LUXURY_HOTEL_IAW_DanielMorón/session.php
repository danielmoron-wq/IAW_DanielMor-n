<?php
// Incluir configuración
require_once 'config.php';

// Solo iniciar sesión si no está ya iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario está logueado
function isLoggedIn() {
    return isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
}

// Redirigir si no está logueado
function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

// Redirigir si ya está logueado (para login page)
function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        header("Location: index.php");
        exit();
    }
}

// Cerrar sesión
function logout() {
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

// Validar campo no vacío
function validarCampoNoVacio($campo, $nombreCampo, &$errores) {
    if (empty($campo)) {
        $errores[] = "El campo '$nombreCampo' es obligatorio.";
        return false;
    }
    return true;
}

// Validar ID
function validarID($id, &$errores) {
    if (empty($id) || !is_numeric($id) || $id <= 0) {
        $errores[] = "El ID debe ser un número válido mayor que 0.";
        return false;
    }
    return true;
}

// Validar email
function validarEmail($email, &$errores) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El formato del email no es válido.";
        return false;
    }
    return true;
}

// Validar número
function validarNumero($numero, $min = null, $max = null, &$errores, $nombreCampo = '') {
    if (!is_numeric($numero)) {
        $errores[] = "El campo '$nombreCampo' debe ser un número.";
        return false;
    }
    
    $num = (float) $numero;
    
    if ($min !== null && $num < $min) {
        $errores[] = "El campo '$nombreCampo' debe ser al menos $min.";
        return false;
    }
    
    if ($max !== null && $num > $max) {
        $errores[] = "El campo '$nombreCampo' no puede ser mayor que $max.";
        return false;
    }
    
    return true;
}

// Conectar a la base de datos
function conectarBD() {
    $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    
    if (!$conn) {
        die("Error de conexión: " . mysqli_connect_error());
    }
    
    mysqli_set_charset($conn, "utf8");
    return $conn;
}
?>