<?php
// Función para mostrar errores (IGUAL QUE LA TUYA)
function mostrarErrores($errores) {
    if (!empty($errores)) {
        echo '<div class="alert alert-danger">';
        echo '<h5><i class="bi bi-exclamation-triangle"></i> Errores encontrados:</h5>';
        echo '<ul>';
        foreach ($errores as $error) {
            echo '<li>' . htmlspecialchars($error) . '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }
}

// Función para mostrar éxito (MEJORADA)
function mostrarExito($mensaje) {
    echo '<div class="alert alert-success alert-dismissible fade show">';
    echo '<i class="bi bi-check-circle me-2"></i>' . htmlspecialchars($mensaje);
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
}

// Función para mostrar información (MEJORADA)
function mostrarInfo($mensaje) {
    echo '<div class="alert alert-info alert-dismissible fade show">';
    echo '<i class="bi bi-info-circle me-2"></i>' . htmlspecialchars($mensaje);
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
}

// Función para mostrar advertencia (NUEVA)
function mostrarAdvertencia($mensaje) {
    echo '<div class="alert alert-warning alert-dismissible fade show">';
    echo '<i class="bi bi-exclamation-triangle me-2"></i>' . htmlspecialchars($mensaje);
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
}

// Función para formatear precio (€)
function formatearPrecio($precio) {
    return '€' . number_format($precio, 2, ',', '.');
}

// Función para formatear fecha
function formatearFecha($fecha) {
    return date('d/m/Y', strtotime($fecha));
}

// Calcular número de noches entre dos fechas
function calcularNoches($fecha_entrada, $fecha_salida) {
    $entrada = new DateTime($fecha_entrada);
    $salida = new DateTime($fecha_salida);
    $diferencia = $entrada->diff($salida);
    return $diferencia->days;
}

// Calcular precio total de una reserva
function calcularPrecioTotal($precio_noche, $fecha_entrada, $fecha_salida) {
    $noches = calcularNoches($fecha_entrada, $fecha_salida);
    return $precio_noche * $noches;
}

// Verificar si una fecha es válida
function validarFecha($fecha) {
    $d = DateTime::createFromFormat('Y-m-d', $fecha);
    return $d && $d->format('Y-m-d') === $fecha;
}
?>