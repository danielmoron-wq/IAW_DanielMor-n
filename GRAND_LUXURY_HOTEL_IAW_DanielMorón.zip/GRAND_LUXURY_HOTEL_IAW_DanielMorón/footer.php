    </div> <!-- Cierre del container principal -->
    
    <!-- Footer -->
    <footer class="footer mt-auto py-3 bg-light border-top">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <span class="text-muted">
                        <i class="bi bi-c-circle"></i> <?php echo date('Y'); ?> - Grand Luxury Hotel
                    </span>
                </div>
                <div class="col-md-6 text-end">
                    <span class="text-muted">
                        Usuario: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></strong>
                    </span>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap 5 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Scripts personalizados -->
    <script>
        // Inicializar tooltips (como en tu proyecto)
        document.addEventListener('DOMContentLoaded', function() {
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });
        
        // Validación de fechas para formularios
        function validarFechas() {
            var fechaEntrada = document.getElementById('fecha_entrada');
            var fechaSalida = document.getElementById('fecha_salida');
            
            if (fechaEntrada && fechaSalida) {
                var entrada = new Date(fechaEntrada.value);
                var salida = new Date(fechaSalida.value);
                var hoy = new Date();
                hoy.setHours(0, 0, 0, 0);
                
                if (entrada < hoy) {
                    alert('La fecha de entrada no puede ser anterior a hoy.');
                    fechaEntrada.value = '';
                    return false;
                }
                
                if (salida <= entrada) {
                    alert('La fecha de salida debe ser posterior a la fecha de entrada.');
                    fechaSalida.value = '';
                    return false;
                }
            }
            return true;
        }
        
        // Confirmar eliminación (como en tu proyecto)
        function confirmarEliminacion(mensaje) {
            return confirm(mensaje || '¿Estás seguro de que deseas eliminar este registro?');
        }
    </script>
</body>
</html>