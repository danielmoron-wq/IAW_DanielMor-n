<?php
require_once 'session.php';
redirectIfNotLoggedIn();

$page_title = 'Dashboard';
include("header.php");
?>

    <!-- Contenido Principal -->
    <div class="container">
        <!-- Banner de bienvenida -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm" style="background: linear-gradient(135deg, #0d6efd 0%, #0dcaf0 100%);">
                    <div class="card-body text-white py-5">
                        <h1 class="display-5 fw-bold mb-3">🏨 Grand Luxury Hotel</h1>
                        <p class="lead mb-0">Sistema de Gestión Hotelera - Panel de Control</p>
                        <div class="mt-3">
                            <span class="badge bg-light text-primary">Usuario: <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <span class="badge bg-light text-primary ms-2"><?php echo date('d/m/Y H:i'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <h2 class="mb-4">📊 Panel de Control</h2>
        
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            
            <!-- Tarjeta Habitaciones -->
            <div class="col">
                <div class="card h-100 border-primary">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-door-closed text-primary"></i> Gestión de Habitaciones
                        </h5>
                        <p class="card-text">Administra las habitaciones del hotel</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <a href="form_insert_room.php" class="text-decoration-none">
                                    <i class="bi bi-plus-circle text-success"></i> Añadir nueva habitación
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="form_search_rooms.php" class="text-decoration-none">
                                    <i class="bi bi-search text-info"></i> Buscar habitaciones disponibles
                                </a>
                            </li>
                            <li>
                                <a href="table_create_rooms.php" class="text-decoration-none">
                                    <i class="bi bi-table text-warning"></i> Crear tabla habitaciones
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Reservas -->
            <div class="col">
                <div class="card h-100 border-success">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-calendar-check text-success"></i> Gestión de Reservas
                        </h5>
                        <p class="card-text">Administra las reservas del hotel</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <a href="form_select_reservations.php" class="text-decoration-none">
                                    <i class="bi bi-list-check text-primary"></i> Ver todas las reservas
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="form_update_reservation.php" class="text-decoration-none">
                                    <i class="bi bi-pencil-square text-warning"></i> Modificar reserva
                                </a>
                            </li>
                            <li>
                                <a href="form_delete_reservation.php" class="text-decoration-none">
                                    <i class="bi bi-trash text-danger"></i> Cancelar reserva
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Base de Datos -->
            <div class="col">
                <div class="card h-100 border-warning">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-database text-warning"></i> Base de Datos
                        </h5>
                        <p class="card-text">Operaciones con la base de datos</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <a href="db_connect.php" class="text-decoration-none">
                                    <i class="bi bi-plug"></i> Conectar a MySQL
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="db_create.php" class="text-decoration-none">
                                    <i class="bi bi-plus-square text-success"></i> Crear base de datos
                                </a>
                            </li>
                            <li>
                                <a href="db_drop.php" class="text-decoration-none">
                                    <i class="bi bi-trash text-danger"></i> Eliminar base de datos
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Tablas -->
            <div class="col">
                <div class="card h-100 border-info">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-table text-info"></i> Tablas
                        </h5>
                        <p class="card-text">Gestión de tablas en la base de datos</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <a href="table_create_rooms.php" class="text-decoration-none">
                                    <i class="bi bi-file-plus"></i> Crear tabla habitaciones
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="table_create_reservations.php" class="text-decoration-none">
                                    <i class="bi bi-file-plus"></i> Crear tabla reservas
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="table_check_exists.php" class="text-decoration-none">
                                    <i class="bi bi-question-circle"></i> Verificar tablas
                                </a>
                            </li>
                            <li>
                                <a href="table_drop.php" class="text-decoration-none">
                                    <i class="bi bi-file-earmark-minus"></i> Eliminar tablas
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Insertar Datos -->
            <div class="col">
                <div class="card h-100 border-secondary">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-cloud-upload text-secondary"></i> Datos Demo
                        </h5>
                        <p class="card-text">Insertar datos de ejemplo</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <a href="data_insert_rooms.php" class="text-decoration-none">
                                    <i class="bi bi-bed"></i> Insertar habitaciones demo
                                </a>
                            </li>
                            <li>
                                <a href="data_insert_reservations.php" class="text-decoration-none">
                                    <i class="bi bi-calendar-plus"></i> Insertar reservas demo
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Tarjeta Información -->
            <div class="col">
                <div class="card h-100 border-danger">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-info-circle text-danger"></i> Información
                        </h5>
                        <p class="card-text">Información sobre el hotel</p>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <a href="about.php" class="text-decoration-none">
                                    <i class="bi bi-building"></i> Sobre el hotel
                                </a>
                            </li>
                            <li class="mb-2">
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
        </div>
        
        <!-- Estadísticas Rápidas -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="card border-0 bg-light">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="bi bi-speedometer2"></i> Información del Sistema
                        </h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Credenciales de Acceso:</strong></p>
                                <ul>
                                    <li>Usuario: <code>admin</code></li>
                                    <li>Contraseña: <code>P4ssw0rd</code></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Base de Datos:</strong></p>
                                <ul>
                                    <li>Nombre: <code>bbdd_dml_mockaroo</code></li>
                                    <li>Usuario BD: <code>dml</code></li>
                                    <li>Contraseña BD: <code>dml</code></li>
                                </ul>
                            </div>
                        </div>
                        <div class="alert alert-info mt-3">
                            <i class="bi bi-lightbulb"></i> 
                            <strong>Consejo:</strong> Comienza creando la base de datos y luego las tablas.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
include("footer.php");
?>