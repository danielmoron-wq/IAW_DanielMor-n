<?php
// Configuración del sistema hotelero

// Credenciales del administrador (login simple como en tu proyecto)
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'P4ssw0rd');

// Credenciales de base de datos (usa tus credenciales dml)
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'dml');
define('DB_PASSWORD', 'dml');
define('DB_NAME', 'bbdd_dml_mockaroo');

// Estados de habitación
define('ESTADO_DISPONIBLE', 'disponible');
define('ESTADO_OCUPADA', 'ocupada');
define('ESTADO_MANTENIMIENTO', 'mantenimiento');
define('ESTADO_LIMPIEZA', 'limpieza');

// Estados de reserva
define('RESERVA_CONFIRMADA', 'confirmada');
define('RESERVA_PENDIENTE', 'pendiente');
define('RESERVA_CANCELADA', 'cancelada');
define('RESERVA_COMPLETADA', 'completada');

// Tipos de habitación
$TIPOS_HABITACION = [
    'sencilla' => 'Habitación Sencilla',
    'doble' => 'Habitación Doble',
    'suite' => 'Suite',
    'deluxe' => 'Suite Deluxe'
];

// Precios por tipo (€ por noche)
$PRECIOS_HABITACION = [
    'sencilla' => 80.00,
    'doble' => 120.00,
    'suite' => 200.00,
    'deluxe' => 350.00
];
?>