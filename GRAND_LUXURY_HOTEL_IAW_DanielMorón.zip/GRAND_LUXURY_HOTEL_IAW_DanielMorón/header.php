<?php
// Verificar si el usuario está logueado (igual que en tu proyecto)
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Título de página (si no está definido)
if (!isset($page_title)) {
    $page_title = 'Grand Luxury Hotel';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="style.css">
    <title><?php echo htmlspecialchars($page_title); ?> - Grand Luxury Hotel</title>
</head>
<body>
    <!-- Navbar Bootstrap (adaptada al hotel) -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-building"></i> Grand Luxury Hotel
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    
                    <!-- Menú Inicio -->
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="bi bi-house"></i> Inicio
                        </a>
                    </li>
                    
                    <!-- Dropdown Habitaciones -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="habitacionesDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-door-closed"></i> Habitaciones
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="habitacionesDropdown">
                            <li>
                                <a class="dropdown-item" href="form_insert_room.php">
                                    <i class="bi bi-plus-circle"></i> Añadir Habitación
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="form_search_rooms.php">
                                    <i class="bi bi-search"></i> Buscar Habitaciones
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Reservas -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="reservasDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-calendar-check"></i> Reservas
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="reservasDropdown">
                            <li>
                                <a class="dropdown-item" href="form_select_reservations.php">
                                    <i class="bi bi-list-check"></i> Ver Reservas
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="form_update_reservation.php">
                                    <i class="bi bi-pencil-square"></i> Modificar Reserva
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="form_delete_reservation.php">
                                    <i class="bi bi-trash"></i> Cancelar Reserva
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Base de Datos (igual que el tuyo) -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="bdDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-server"></i> Base de Datos
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="bdDropdown">
                            <li>
                                <a class="dropdown-item" href="db_connect.php">
                                    <i class="bi bi-plug"></i> Conectar
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="db_create.php">
                                    <i class="bi bi-plus-square"></i> Crear BD
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="db_drop.php">
                                    <i class="bi bi-trash"></i> Borrar BD
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Tablas (igual que el tuyo) -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="tablasDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-table"></i> Tablas
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="tablasDropdown">
                            <li>
                                <a class="dropdown-item" href="table_create_rooms.php">
                                    <i class="bi bi-file-plus"></i> Crear Tabla Habitaciones
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="table_create_reservations.php">
                                    <i class="bi bi-file-plus"></i> Crear Tabla Reservas
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="table_check_exists.php">
                                    <i class="bi bi-question-circle"></i> Verificar Tablas
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="table_drop.php">
                                    <i class="bi bi-file-earmark-minus"></i> Borrar Tablas
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- Dropdown Insertar Datos (igual que el tuyo) -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="insertarDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-cloud-upload"></i> Insertar Datos
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="insertarDropdown">
                            <li>
                                <a class="dropdown-item" href="data_insert_rooms.php">
                                    <i class="bi bi-bed"></i> Insertar Habitaciones
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="data_insert_reservations.php">
                                    <i class="bi bi-calendar-plus"></i> Insertar Reservas
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                </ul>
                
                <!-- Usuario y Logout (igual que el tuyo) -->
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle"></i> 
                            <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li>
                                <a class="dropdown-item" href="logout_confirm.php">
                                    <i class="bi bi-box-arrow-right"></i> Cerrar Sesión
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Contenido principal -->
    <div class="container mt-5 pt-4">