<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bbdd_dml_mockaroo";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("<div class='alert alert-danger'>Connection failed: " . mysqli_connect_error() . "</div>");
}

// INCLUIR CABECERA
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-table"></i> Crear Tabla Reservas</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="bi bi-calendar-check"></i> Crear Tabla: Reservas</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                Se creará la tabla <strong>reservas</strong> en la base de datos <strong><?php echo htmlspecialchars($dbname); ?></strong>
            </div>
            
            <?php
            // sql to create table
            $sql = "CREATE TABLE IF NOT EXISTS reservas (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                codigo_reserva VARCHAR(20) NOT NULL UNIQUE,
                cliente_nombre VARCHAR(100) NOT NULL,
                cliente_email VARCHAR(100) NOT NULL,
                cliente_telefono VARCHAR(15),
                habitacion_id INT(6) UNSIGNED NOT NULL,
                fecha_entrada DATE NOT NULL,
                fecha_salida DATE NOT NULL,
                noches INT NOT NULL,
                precio_total DECIMAL(10,2) NOT NULL,
                estado ENUM('pendiente', 'confirmada', 'cancelada', 'completada') DEFAULT 'confirmada',
                observaciones TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";

            if (mysqli_query($conn, $sql) == false) {
                echo '<div class="alert alert-danger">';
                echo '<i class="bi bi-exclamation-triangle me-2"></i>';
                echo '<strong>Error creando tabla:</strong> ' . mysqli_error($conn);
                echo '</div>';
            } else {
                echo '<div class="alert alert-success">';
                echo '<i class="bi bi-check-circle me-2"></i>';
                echo '<strong>Tabla creada exitosamente:</strong> reservas';
                echo '</div>';
            }
            ?>
            
            <div class="card mb-3">
                <div class="card-body">
                    <h6><i class="bi bi-columns me-2"></i>Estructura de la tabla:</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Campo</th>
                                    <th>Tipo</th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><code>id</code></td>
                                    <td>INT AUTO_INCREMENT</td>
                                    <td>Identificador único</td>
                                </tr>
                                <tr>
                                    <td><code>codigo_reserva</code></td>
                                    <td>VARCHAR(20)</td>
                                    <td>Código único de reserva</td>
                                </tr>
                                <tr>
                                    <td><code>cliente_nombre</code></td>
                                    <td>VARCHAR(100)</td>
                                    <td>Nombre completo del cliente</td>
                                </tr>
                                <tr>
                                    <td><code>cliente_email</code></td>
                                    <td>VARCHAR(100)</td>
                                    <td>Email del cliente</td>
                                </tr>
                                <tr>
                                    <td><code>cliente_telefono</code></td>
                                    <td>VARCHAR(15)</td>
                                    <td>Teléfono del cliente</td>
                                </tr>
                                <tr>
                                    <td><code>habitacion_id</code></td>
                                    <td>INT UNSIGNED</td>
                                    <td>ID de la habitación reservada</td>
                                </tr>
                                <tr>
                                    <td><code>fecha_entrada</code></td>
                                    <td>DATE</td>
                                    <td>Fecha de check-in</td>
                                </tr>
                                <tr>
                                    <td><code>fecha_salida</code></td>
                                    <td>DATE</td>
                                    <td>Fecha de check-out</td>
                                </tr>
                                <tr>
                                    <td><code>noches</code></td>
                                    <td>INT</td>
                                    <td>Número de noches</td>
                                </tr>
                                <tr>
                                    <td><code>precio_total</code></td>
                                    <td>DECIMAL(10,2)</td>
                                    <td>Precio total (€)</td>
                                </tr>
                                <tr>
                                    <td><code>estado</code></td>
                                    <td>ENUM</td>
                                    <td>Estado de la reserva</td>
                                </tr>
                                <tr>
                                    <td><code>observaciones</code></td>
                                    <td>TEXT</td>
                                    <td>Observaciones adicionales</td>
                                </tr>
                                <tr>
                                    <td><code>created_at</code></td>
                                    <td>TIMESTAMP</td>
                                    <td>Fecha de creación</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="alert alert-success">
                <h6><i class="bi bi-lightbulb me-2"></i>Sistema listo:</h6>
                <ul class="mb-0">
                    <li>✓ Base de datos creada</li>
                    <li>✓ Tabla de habitaciones creada</li>
                    <li>✓ Tabla de reservas creada</li>
                    <li>¡Ahora puedes insertar datos y usar el sistema!</li>
                </ul>
            </div>
            
            <div class="d-grid gap-2 d-md-flex">
                <a href="data_insert_reservations.php" class="btn btn-warning">
                    <i class="bi bi-cloud-upload me-2"></i>Insertar Reservas Demo
                </a>
                <a href="table_check_exists.php" class="btn btn-outline-info">
                    <i class="bi bi-question-circle me-2"></i>Verificar Tablas
                </a>
                <a href="form_insert_room.php" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-2"></i>Añadir Habitación
                </a>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-house me-2"></i>Ir al Inicio
                </a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>