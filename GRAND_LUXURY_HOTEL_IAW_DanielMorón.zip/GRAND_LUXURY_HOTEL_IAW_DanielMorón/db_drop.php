<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bbdd_dml_mockaroo";

// Primero conectar sin base de datos
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
  die("<div class='alert alert-danger'>Connection failed: " . mysqli_connect_error() . "</div>");
}

// INCLUIR CABECERA
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-database-dash"></i> Eliminar Base de Datos</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-danger text-white">
            <h5 class="mb-0"><i class="bi bi-database-dash"></i> Eliminar Base de Datos</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <strong>ADVERTENCIA:</strong> Esta acción eliminará permanentemente la base de datos: 
                <strong><?php echo htmlspecialchars($dbname); ?></strong>
                <br>Todos los datos se perderán.
            </div>
            
            <?php
            // Primero verificar si la base de datos existe
            $sql_check = "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbname'";
            $result_check = mysqli_query($conn, $sql_check);
            $db_exists = mysqli_num_rows($result_check) > 0;
            
            if ($db_exists) {
                // sql to delete database
                $sql = "DROP DATABASE IF EXISTS $dbname";

                if (mysqli_query($conn, $sql) == false) {
                    echo '<div class="alert alert-danger">';
                    echo '<i class="bi bi-exclamation-triangle me-2"></i>';
                    echo '<strong>Error eliminando base de datos:</strong> ' . mysqli_error($conn);
                    echo '</div>';
                } else {
                    echo '<div class="alert alert-success">';
                    echo '<i class="bi bi-check-circle me-2"></i>';
                    echo '<strong>Base de datos eliminada:</strong> ' . htmlspecialchars($dbname);
                    echo '</div>';
                }
            } else {
                echo '<div class="alert alert-info">';
                echo '<i class="bi bi-info-circle me-2"></i>';
                echo 'La base de datos <strong>' . htmlspecialchars($dbname) . '</strong> no existe.';
                echo '</div>';
            }
            ?>
            
            <div class="card mb-3">
                <div class="card-body">
                    <h6><i class="bi bi-info-circle me-2"></i>Detalles de la operación:</h6>
                    <table class="table table-sm">
                        <tr>
                            <td width="30%"><strong>Base de datos:</strong></td>
                            <td><?php echo htmlspecialchars($dbname); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Comando SQL:</strong></td>
                            <td><code>DROP DATABASE IF EXISTS <?php echo htmlspecialchars($dbname); ?></code></td>
                        </tr>
                        <tr>
                            <td><strong>Estado:</strong></td>
                            <td>
                                <?php if ($db_exists): ?>
                                    <span class="badge bg-danger">Eliminada</span>
                                <?php else: ?>
                                    <span class="badge bg-warning">No existía</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div class="alert alert-info">
                <h6><i class="bi bi-lightbulb me-2"></i>¿Qué hacer ahora?</h6>
                <ul class="mb-0">
                    <li>Si quieres empezar de nuevo, crea la base de datos</li>
                    <li>Luego crea las tablas necesarias</li>
                    <li>Finalmente inserta datos de ejemplo</li>
                </ul>
            </div>
            
            <div class="d-grid gap-2 d-md-flex">
                <a href="db_create.php" class="btn btn-primary">
                    <i class="bi bi-database-add me-2"></i>Crear Base de Datos
                </a>
                <a href="db_connect.php" class="btn btn-outline-primary">
                    <i class="bi bi-plug me-2"></i>Conectar a MySQL
                </a>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-house me-2"></i>Ir al Inicio
                </a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>