<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Incluir archivos necesarios
require_once 'recoge.php';
require_once 'session.php';
require_once 'funciones.php';

$errores = [];
$exito = false;
$id = recoge('id');
$new_estado = recoge('new_estado');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar ID
    if (empty($id) || !is_numeric($id)) {
        $errores[] = "El ID no es válido.";
    }
    
    validarCampoNoVacio($new_estado, "Nuevo estado", $errores);
    
    // Validar que el estado sea válido
    if (!empty($new_estado) && !in_array($new_estado, ['pendiente', 'confirmada', 'cancelada', 'completada'])) {
        $errores[] = "El estado '$new_estado' no es válido. Use: pendiente, confirmada, cancelada o completada.";
    }
    
    if (empty($errores)) {
        $conn = conectarBD();
        
        if (!$conn) {
            $errores[] = "Error al conectar a la base de datos.";
        } else {
            $sql_check = "SELECT codigo_reserva, cliente_nombre, cliente_email, estado, habitacion_id FROM reservas WHERE id = ?";
            $stmt_check = mysqli_prepare($conn, $sql_check);
            
            if ($stmt_check) {
                mysqli_stmt_bind_param($stmt_check, "i", $id);
                mysqli_stmt_execute($stmt_check);
                mysqli_stmt_store_result($stmt_check);
                
                if (mysqli_stmt_num_rows($stmt_check) == 0) {
                    $errores[] = "No existe ninguna reserva con el ID $id.";
                } else {
                    mysqli_stmt_bind_result($stmt_check, $codigo_reserva, $cliente_nombre, $cliente_email, $current_estado, $habitacion_id);
                    mysqli_stmt_fetch($stmt_check);
                    
                    $sql_update = "UPDATE reservas SET estado = ? WHERE id = ?";
                    $stmt_update = mysqli_prepare($conn, $sql_update);
                    
                    if ($stmt_update) {
                        mysqli_stmt_bind_param($stmt_update, "si", $new_estado, $id);
                        
                        if (mysqli_stmt_execute($stmt_update)) {
                            if (mysqli_affected_rows($conn) > 0) {
                                $exito = true;
                                $mensaje_exito = "<strong>Reserva actualizada correctamente:</strong><br>";
                                $mensaje_exito .= "• ID: $id<br>";
                                $mensaje_exito .= "• Código: $codigo_reserva<br>";
                                $mensaje_exito .= "• Cliente: $cliente_nombre<br>";
                                $mensaje_exito .= "• Email: $cliente_email<br>";
                                $mensaje_exito .= "• Estado anterior: $current_estado<br>";
                                $mensaje_exito .= "• Estado nuevo: $new_estado";
                                
                                // Si el nuevo estado es "cancelada" o "completada", marcar habitación como disponible
                                if (in_array($new_estado, ['cancelada', 'completada'])) {
                                    $sql_update_habitacion = "UPDATE habitaciones SET estado = 'disponible' WHERE id = ?";
                                    $stmt_update_hab = mysqli_prepare($conn, $sql_update_habitacion);
                                    if ($stmt_update_hab) {
                                        mysqli_stmt_bind_param($stmt_update_hab, "i", $habitacion_id);
                                        mysqli_stmt_execute($stmt_update_hab);
                                        mysqli_stmt_close($stmt_update_hab);
                                        
                                        $mensaje_exito .= "<br>• Habitación: Marcada como 'disponible'";
                                    }
                                }
                                
                                $id = '';
                                $new_estado = '';
                            } else {
                                $errores[] = "No se realizaron cambios (posiblemente el nuevo estado es igual al anterior).";
                            }
                        } else {
                            $errores[] = "Error al actualizar reserva: " . mysqli_error($conn);
                        }
                        
                        mysqli_stmt_close($stmt_update);
                    } else {
                        $errores[] = "Error preparando la consulta de actualización.";
                    }
                }
                
                mysqli_stmt_close($stmt_check);
            } else {
                $errores[] = "Error preparando la consulta de verificación.";
            }
            
            mysqli_close($conn);
        }
    }
}

include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-pencil-square"></i> Modificar Estado de Reserva</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0"><i class="bi bi-pencil-square"></i> Modificar Estado de Reserva</h5>
        </div>
        <div class="card-body">
            <?php 
            mostrarErrores($errores);
            if ($exito) {
                echo '<div class="alert alert-success">' . $mensaje_exito . '</div>';
            }
            ?>
            
            <form method="POST" action="">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="id" class="form-label">ID de la reserva *</label>
                        <input type="number" class="form-control" id="id" name="id" 
                               value="<?php echo htmlspecialchars($id); ?>"
                               required min="1" step="1">
                        <div class="form-text">ID numérico de la reserva a modificar</div>
                    </div>
                    
                    <div class="col-md-6">
                        <label for="new_estado" class="form-label">Nuevo estado *</label>
                        <select class="form-select" id="new_estado" name="new_estado" required>
                            <option value="">-- Seleccionar estado --</option>
                            <option value="pendiente" <?php echo $new_estado == 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                            <option value="confirmada" <?php echo $new_estado == 'confirmada' ? 'selected' : ''; ?>>Confirmada</option>
                            <option value="cancelada" <?php echo $new_estado == 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                            <option value="completada" <?php echo $new_estado == 'completada' ? 'selected' : ''; ?>>Completada</option>
                        </select>
                        <div class="form-text">Selecciona el nuevo estado de la reserva</div>
                    </div>
                </div>
                
                <div class="mt-4 d-grid gap-2 d-md-flex">
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-pencil-square"></i> Actualizar Estado
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="bi bi-arrow-clockwise"></i> Limpiar
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Volver
                    </a>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle"></i> 
                Este formulario actualizará únicamente el estado de la reserva especificada.
                <br><strong>Nota:</strong> Al cambiar a "cancelada" o "completada", la habitación asociada se marcará automáticamente como "disponible".
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>