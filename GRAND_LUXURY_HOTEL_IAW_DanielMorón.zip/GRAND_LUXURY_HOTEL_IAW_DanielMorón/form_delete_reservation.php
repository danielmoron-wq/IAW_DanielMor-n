<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

include("recoge.php");
include("session.php");

$errores = [];
$exito = false;
$id = recoge('id');
$confirmado = recoge('confirmado') === 'si';

if ($_SERVER["REQUEST_METHOD"] == "POST" && $confirmado) {
    // Validar ID
    if (empty($id) || !is_numeric($id)) {
        $errores[] = "El ID no es válido.";
    } else {
        $conn = conectarBD();
        
        $sql_check = "SELECT id, codigo_reserva, cliente_nombre, cliente_email, habitacion_id FROM reservas WHERE id = ?";
        $stmt_check = mysqli_prepare($conn, $sql_check);
        mysqli_stmt_bind_param($stmt_check, "i", $id);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);
        
        if (mysqli_stmt_num_rows($stmt_check) == 0) {
            $errores[] = "No existe ninguna reserva con el ID $id.";
        } else {
            mysqli_stmt_bind_result($stmt_check, $id_reg, $codigo_reserva, $cliente_nombre, $cliente_email, $habitacion_id);
            mysqli_stmt_fetch($stmt_check);
            
            // Primero marcar la habitación como disponible
            $sql_update_habitacion = "UPDATE habitaciones SET estado = 'disponible' WHERE id = ?";
            $stmt_update = mysqli_prepare($conn, $sql_update_habitacion);
            mysqli_stmt_bind_param($stmt_update, "i", $habitacion_id);
            mysqli_stmt_execute($stmt_update);
            mysqli_stmt_close($stmt_update);
            
            // Luego eliminar la reserva
            $sql_delete = "DELETE FROM reservas WHERE id = ?";
            $stmt_delete = mysqli_prepare($conn, $sql_delete);
            mysqli_stmt_bind_param($stmt_delete, "i", $id);
            
            if (mysqli_stmt_execute($stmt_delete)) {
                if (mysqli_affected_rows($conn) > 0) {
                    $exito = true;
                    $mensaje_exito = "Reserva eliminada correctamente: $cliente_nombre (Código: $codigo_reserva, ID: $id)";
                    $id = '';
                }
            } else {
                $errores[] = "Error al eliminar reserva: " . mysqli_error($conn);
            }
            
            mysqli_stmt_close($stmt_delete);
        }
        
        mysqli_stmt_close($stmt_check);
        mysqli_close($conn);
    }
}

include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-trash"></i> Eliminar Reserva</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-danger text-white">
            <h5 class="mb-0"><i class="bi bi-trash"></i> Eliminar Reserva</h5>
        </div>
        <div class="card-body">
            <?php 
            include("funciones.php");
            mostrarErrores($errores);
            if ($exito) {
                mostrarExito($mensaje_exito);
            }
            ?>
            
            <?php if (!$confirmado): ?>
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle"></i> 
                    <strong>Advertencia:</strong> Esta acción eliminará permanentemente la reserva de la base de datos.
                    <br>La habitación asociada será marcada automáticamente como "disponible".
                </div>
                
                <form method="POST" action="" id="deleteForm">
                    <div class="mb-3">
                        <label for="id" class="form-label">ID de la reserva a eliminar *</label>
                        <input type="number" class="form-control" id="id" name="id" 
                               value="<?php echo htmlspecialchars($id); ?>"
                               required min="1" step="1">
                        <div class="form-text">Introduce el ID numérico de la reserva que deseas eliminar</div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex">
                        <button type="submit" name="confirmado" value="si" 
                                class="btn btn-danger" 
                                onclick="return confirm('¿Estás seguro de ELIMINAR esta reserva?\\n\\nEsta acción NO se puede deshacer.\\n\\nLa reserva se eliminará permanentemente.')">
                            <i class="bi bi-trash"></i> Eliminar Reserva
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-x-circle"></i> Cancelar
                        </a>
                    </div>
                </form>
            <?php else: ?>
                <div class="text-center py-4">
                    <div class="mb-3">
                        <i class="bi bi-check-circle text-success" style="font-size: 3rem;"></i>
                    </div>
                    <h5 class="text-success">Reserva Eliminada</h5>
                    <p class="text-muted">La reserva ha sido eliminada permanentemente de la base de datos.</p>
                    <p class="text-muted">La habitación asociada ahora está disponible para nuevas reservas.</p>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-center mt-4">
                        <a href="form_delete_reservation.php" class="btn btn-primary">
                            <i class="bi bi-trash"></i> Eliminar otra reserva
                        </a>
                        <a href="form_select_reservations.php" class="btn btn-outline-primary">
                            <i class="bi bi-list-check"></i> Ver todas las reservas
                        </a>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-house"></i> Volver al inicio
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle"></i> 
                Esta acción es irreversible. La reserva se eliminará permanentemente de la base de datos.
                <br>La habitación asociada se marcará automáticamente como "disponible".
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>