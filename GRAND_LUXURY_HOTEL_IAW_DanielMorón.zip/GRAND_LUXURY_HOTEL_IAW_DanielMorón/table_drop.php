<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}
$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bbdd_dml_mockaroo";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// INCLUIR CABECERA
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-trash"></i> Eliminar Tablas</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-danger text-white">
            <h5 class="mb-0"><i class="bi bi-trash"></i> Eliminar Tablas</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle me-2"></i>
                <strong>ADVERTENCIA:</strong> Esta acción eliminará permanentemente las tablas de la base de datos.
                <br>Todos los datos contenidos en las tablas se perderán.
            </div>
            
            <?php
            // Tablas a eliminar
            $tablas = ['habitaciones', 'reservas'];
            $resultados = [];
            
            foreach ($tablas as $tabla) {
                $sql = "DROP TABLE IF EXISTS $tabla";
                
                if (mysqli_query($conn, $sql) == false) {
                    $resultados[$tabla] = [
                        'success' => false,
                        'message' => 'Error: ' . mysqli_error($conn)
                    ];
                } else {
                    $resultados[$tabla] = [
                        'success' => true,
                        'message' => 'Tabla eliminada (si existía)'
                    ];
                }
            }
            ?>
            
            <div class="card mb-3">
                <div class="card-body">
                    <h6><i class="bi bi-list-check me-2"></i>Resultados de la operación:</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Tabla</th>
                                    <th>Comando SQL</th>
                                    <th>Resultado</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($resultados as $tabla => $resultado): ?>
                                <tr>
                                    <td><code><?php echo htmlspecialchars($tabla); ?></code></td>
                                    <td><code>DROP TABLE IF EXISTS <?php echo htmlspecialchars($tabla); ?></code></td>
                                    <td><?php echo htmlspecialchars($resultado['message']); ?></td>
                                    <td>
                                        <?php if ($resultado['success']): ?>
                                            <span class="badge bg-success">Éxito</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Error</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php
            // Verificar qué tablas quedan
            $sql_check = "SHOW TABLES";
            $result_check = mysqli_query($conn, $sql_check);
            $tablas_restantes = mysqli_num_rows($result_check);
            ?>
            
            <div class="alert <?php echo $tablas_restantes == 0 ? 'alert-success' : 'alert-info'; ?>">
                <i class="bi bi-info-circle me-2"></i>
                Después de la operación, quedan <strong><?php echo $tablas_restantes; ?></strong> tabla(s) en la base de datos.
            </div>
            
            <?php if ($tablas_restantes > 0): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h6><i class="bi bi-table me-2"></i>Tablas restantes:</h6>
                    <ul>
                        <?php while ($row = mysqli_fetch_array($result_check)): ?>
                            <li><code><?php echo htmlspecialchars($row[0]); ?></code></li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="alert alert-info">
                <h6><i class="bi bi-lightbulb me-2"></i>¿Qué hacer ahora?</h6>
                <ul class="mb-0">
                    <li>Si quieres empezar de nuevo, crea las tablas necesarias</li>
                    <li>Puedes crear tablas individuales o todas a la vez</li>
                    <li>Después de crear las tablas, inserta datos de ejemplo</li>
                </ul>
            </div>
            
            <div class="d-grid gap-2 d-md-flex">
                <a href="table_create_rooms.php" class="btn btn-primary">
                    <i class="bi bi-door-closed me-2"></i>Crear Tabla Habitaciones
                </a>
                <a href="table_create_reservations.php" class="btn btn-success">
                    <i class="bi bi-calendar-check me-2"></i>Crear Tabla Reservas
                </a>
                <a href="db_drop.php" class="btn btn-danger">
                    <i class="bi bi-database-dash me-2"></i>Eliminar Base de Datos
                </a>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-house me-2"></i>Ir al Inicio
                </a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>