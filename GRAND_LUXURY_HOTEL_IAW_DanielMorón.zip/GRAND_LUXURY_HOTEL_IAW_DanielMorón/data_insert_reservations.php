<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bbdd_dml_mockaroo";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("<div style='color: red;'>Connection failed: " . mysqli_connect_error() . "</div>");
}

// INCLUIR CABECERA
include("header.php");
?>

<div class="container">
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="bi bi-calendar-plus"></i> Insertar Reservas Demo</h5>
        </div>
        <div class="card-body">
            <?php
            echo "<div class='alert alert-info'>Connected successfully</div>";
            
            // Primero, verificar si ya existen reservas con estos códigos
            $codigos_reserva = ['RES-2024-001', 'RES-2024-002', 'RES-2024-003'];
            $reservas_existentes = [];
            
            foreach ($codigos_reserva as $codigo) {
                $sql_check = "SELECT id FROM reservas WHERE codigo_reserva = '$codigo'";
                $result_check = mysqli_query($conn, $sql_check);
                if (mysqli_num_rows($result_check) > 0) {
                    $reservas_existentes[] = $codigo;
                }
            }
            
            if (!empty($reservas_existentes)) {
                echo "<div class='alert alert-warning'>";
                echo "<i class='bi bi-exclamation-triangle'></i> ";
                echo "Ya existen reservas con los códigos: " . implode(', ', $reservas_existentes) . "<br>";
                echo "Se omitirá la inserción de estas reservas para evitar duplicados.";
                echo "</div>";
            }
            
            // Preparar las consultas usando INSERT IGNORE para evitar errores de duplicados
            $reservas_insertadas = 0;
            $reservas_omitidas = 0;
            $errores_insert = [];
            
            // Reserva 1 - Solo insertar si no existe
            $sql1 = "INSERT IGNORE INTO reservas (codigo_reserva, cliente_nombre, cliente_email, cliente_telefono, habitacion_id, fecha_entrada, fecha_salida, noches, precio_total, estado, observaciones) 
                    VALUES ('RES-2024-001', 'Juan Pérez', 'juan@email.com', '611223344', 1, '2024-01-15', '2024-01-18', 3, 240.00, 'confirmada', 'Cliente frecuente')";
            
            // Reserva 2 - Solo insertar si no existe
            $sql2 = "INSERT IGNORE INTO reservas (codigo_reserva, cliente_nombre, cliente_email, cliente_telefono, habitacion_id, fecha_entrada, fecha_salida, noches, precio_total, estado, observaciones) 
                    VALUES ('RES-2024-002', 'María García', 'maria@email.com', '622334455', 3, '2024-01-20', '2024-01-25', 5, 600.00, 'confirmada', 'Requiere cuna para bebé')";
            
            // Reserva 3 - Solo insertar si no existe
            $sql3 = "INSERT IGNORE INTO reservas (codigo_reserva, cliente_nombre, cliente_email, cliente_telefono, habitacion_id, fecha_entrada, fecha_salida, noches, precio_total, estado, observaciones) 
                    VALUES ('RES-2024-003', 'Carlos López', 'carlos@email.com', '633445566', 6, '2024-02-01', '2024-02-03', 2, 400.00, 'pendiente', 'Por confirmar pago')";
            
            // Ejecutar cada consulta por separado
            if (mysqli_query($conn, $sql1)) {
                if (mysqli_affected_rows($conn) > 0) {
                    $reservas_insertadas++;
                } else {
                    $reservas_omitidas++;
                }
            } else {
                $errores_insert[] = "Error insertando reserva 1: " . mysqli_error($conn);
            }
            
            if (mysqli_query($conn, $sql2)) {
                if (mysqli_affected_rows($conn) > 0) {
                    $reservas_insertadas++;
                } else {
                    $reservas_omitidas++;
                }
            } else {
                $errores_insert[] = "Error insertando reserva 2: " . mysqli_error($conn);
            }
            
            if (mysqli_query($conn, $sql3)) {
                if (mysqli_affected_rows($conn) > 0) {
                    $reservas_insertadas++;
                } else {
                    $reservas_omitidas++;
                }
            } else {
                $errores_insert[] = "Error insertando reserva 3: " . mysqli_error($conn);
            }
            
            // Mostrar resultados
            echo "<div class='alert alert-success'>";
            echo "<i class='bi bi-check-circle'></i> ";
            echo "Operación completada:<br>";
            echo "- Reservas insertadas: <strong>$reservas_insertadas</strong><br>";
            echo "- Reservas omitidas (ya existían): <strong>$reservas_omitidas</strong>";
            echo "</div>";
            
            // Solo actualizar estado de las habitaciones si se insertaron nuevas reservas
            if ($reservas_insertadas > 0) {
                $sql_update = "UPDATE habitaciones SET estado = 'ocupada' WHERE id IN (1, 3, 6) AND estado != 'ocupada'";
                if (mysqli_query($conn, $sql_update)) {
                    $filas_actualizadas = mysqli_affected_rows($conn);
                    if ($filas_actualizadas > 0) {
                        echo "<div class='alert alert-info'>Estado de $filas_actualizadas habitación(es) actualizado a 'ocupada'.</div>";
                    }
                } else {
                    echo "<div class='alert alert-warning'>Error actualizando habitaciones: " . mysqli_error($conn) . "</div>";
                }
            }
            
            if (!empty($errores_insert)) {
                echo "<div class='alert alert-danger'>";
                echo "<strong>Errores encontrados:</strong><br>";
                foreach ($errores_insert as $error) {
                    echo "- " . $error . "<br>";
                }
                echo "</div>";
            }
            ?>
            
            <div class="table-responsive mt-3">
                <table class="table table-striped">
                    <thead class="table-dark">
                        <tr><th>Código</th><th>Cliente</th><th>Email</th><th>Teléfono</th><th>Habitación</th><th>Fechas</th><th>Noches</th><th>Total</th><th>Estado</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $reservas = [
                            ['RES-2024-001', 'Juan Pérez', 'juan@email.com', '611223344', 1, '2024-01-15', '2024-01-18', 3, 240.00, 'confirmada'],
                            ['RES-2024-002', 'María García', 'maria@email.com', '622334455', 3, '2024-01-20', '2024-01-25', 5, 600.00, 'confirmada'],
                            ['RES-2024-003', 'Carlos López', 'carlos@email.com', '633445566', 6, '2024-02-01', '2024-02-03', 2, 400.00, 'pendiente']
                        ];

                        foreach ($reservas as $r) {
                            $badge_class = '';
                            switch ($r[9]) {
                                case 'confirmada': $badge_class = 'bg-success'; break;
                                case 'pendiente': $badge_class = 'bg-warning'; break;
                                case 'cancelada': $badge_class = 'bg-danger'; break;
                                case 'completada': $badge_class = 'bg-info'; break;
                            }
                            
                            // Verificar si esta reserva ya existe
                            $existe = in_array($r[0], $reservas_existentes);
                            $fila_clase = $existe ? 'table-warning' : '';
                            
                            echo "<tr class='$fila_clase'>";
                            echo "<td><code>" . $r[0] . "</code>";
                            if ($existe) {
                                echo " <span class='badge bg-warning'>Ya existe</span>";
                            }
                            echo "</td>";
                            echo "<td>" . $r[1] . "</td>";
                            echo "<td>" . $r[2] . "</td>";
                            echo "<td>" . $r[3] . "</td>";
                            echo "<td>Hab. " . $r[4] . "</td>";
                            echo "<td>" . $r[5] . " a " . $r[6] . "</td>";
                            echo "<td>" . $r[7] . "</td>";
                            echo "<td class='text-success fw-bold'>€" . number_format($r[8], 2) . "</td>";
                            echo "<td><span class='badge $badge_class'>" . $r[9] . "</span></td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <div class="alert alert-success mt-3">
                <h6><i class="bi bi-check-circle"></i> Sistema listo para usar:</h6>
                <ul class="mb-0">
                    <li>✓ Base de datos creada</li>
                    <li>✓ Tablas creadas</li>
                    <li>✓ Habitaciones insertadas</li>
                    <li>✓ Reservas insertadas/verificadas</li>
                    <li>¡Ahora puedes usar todos los formularios!</li>
                </ul>
            </div>
            
            <div class="d-grid gap-2 d-md-flex mt-3">
                <a href="index.php" class="btn btn-primary">Volver al Inicio</a>
                <a href="form_select_reservations.php" class="btn btn-success">Ver Reservas</a>
                <a href="form_search_rooms.php" class="btn btn-warning">Buscar Habitaciones</a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>