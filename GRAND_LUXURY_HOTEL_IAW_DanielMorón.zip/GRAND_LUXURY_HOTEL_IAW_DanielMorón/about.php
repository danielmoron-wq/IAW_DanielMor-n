<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}
require_once 'session.php';
redirectIfNotLoggedIn();

$page_title = 'Sobre el Hotel';
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-building"></i> Sobre el Hotel</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-building"></i> Grand Luxury Hotel</h5>
        </div>
        <div class="card-body">
            <!-- Banner principal -->
            <div class="text-center mb-5">
                <h1 class="display-4 text-primary">Grand Luxury Hotel</h1>
                <p class="lead">Excelencia y confort en el corazón de la ciudad</p>
            </div>
            
            <!-- Historia del hotel -->
            <div class="row mb-5">
                <div class="col-md-6">
                    <h3 class="border-bottom pb-2 mb-3">Nuestra Historia</h3>
                    <p>Fundado en 1995, el <strong>Grand Luxury Hotel</strong> nació con la visión de crear un refugio de lujo y sofisticación en el corazón de la ciudad. Desde sus inicios, nos hemos comprometido a ofrecer experiencias excepcionales a nuestros huéspedes.</p>
                    <p>Con más de 25 años de historia, hemos sido testigos y partícipes de momentos inolvidables, desde bodas de ensueño hasta importantes convenciones internacionales. Nuestro compromiso con la excelencia nos ha convertido en un referente del sector hotelero.</p>
                </div>
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h5><i class="bi bi-award text-warning"></i> Premios y Reconocimientos</h5>
                            <ul class="list-unstyled">
                                <li class="mb-2"><i class="bi bi-check-circle text-success"></i> Mejor Hotel de Lujo 2023</li>
                                <li class="mb-2"><i class="bi bi-check-circle text-success"></i> 5 Estrellas AAA desde 2010</li>
                                <li class="mb-2"><i class="bi bi-check-circle text-success"></i> Certificación de Sostenibilidad Eco-Hotel</li>
                                <li class="mb-2"><i class="bi bi-check-circle text-success"></i> Premio a la Excelencia en Servicio 2022</li>
                                <li><i class="bi bi-check-circle text-success"></i> Mejor Desayuno Gourmet 2023</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Instalaciones -->
            <div class="row mb-5">
                <div class="col-12">
                    <h3 class="border-bottom pb-2 mb-4">Nuestras Instalaciones</h3>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="bi bi-door-closed display-6 text-primary mb-3"></i>
                            <h5>Habitaciones de Lujo</h5>
                            <p class="card-text">Amplias habitaciones y suites con decoración elegante, vistas panorámicas y todas las comodidades modernas.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="bi bi-cup-straw display-6 text-primary mb-3"></i>
                            <h5>Restaurante Gourmet</h5>
                            <p class="card-text">Cocina internacional de alta calidad dirigida por nuestro chef estrella Michelin, con ingredientes locales de temporada.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="bi bi-water display-6 text-primary mb-3"></i>
                            <h5>Spa y Bienestar</h5>
                            <p class="card-text">Centro de bienestar completo con piscina climatizada, jacuzzi, sauna finlandesa y tratamientos de spa personalizados.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Tipos de habitaciones -->
            <div class="row mb-5">
                <div class="col-12">
                    <h3 class="border-bottom pb-2 mb-4">Tipos de Habitaciones</h3>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card border-success h-100">
                        <div class="card-header bg-success text-white">
                            <h6 class="mb-0">Habitación Sencilla</h6>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title text-success">€80/noche</h5>
                            <p class="card-text">Ideal para viajeros individuales. Cama king size, baño privado y escritorio de trabajo.</p>
                            <ul class="list-unstyled">
                                <li><i class="bi bi-check text-success"></i> 1 persona</li>
                                <li><i class="bi bi-check text-success"></i> WiFi gratuito</li>
                                <li><i class="bi bi-check text-success"></i> TV pantalla plana</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card border-primary h-100">
                        <div class="card-header bg-primary text-white">
                            <h6 class="mb-0">Habitación Doble</h6>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title text-primary">€120/noche</h5>
                            <p class="card-text">Perfecta para parejas. Cama king size o dos camas individuales, balcón privado.</p>
                            <ul class="list-unstyled">
                                <li><i class="bi bi-check text-primary"></i> 2 personas</li>
                                <li><i class="bi bi-check text-primary"></i> Balcón privado</li>
                                <li><i class="bi bi-check text-primary"></i> Mini-bar</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card border-warning h-100">
                        <div class="card-header bg-warning text-dark">
                            <h6 class="mb-0">Suite</h6>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title text-warning">€200/noche</h5>
                            <p class="card-text">Amplia suite con sala de estar separada. Ideal para familias pequeñas o viajes de negocios.</p>
                            <ul class="list-unstyled">
                                <li><i class="bi bi-check text-warning"></i> 3-4 personas</li>
                                <li><i class="bi bi-check text-warning"></i> Sala de estar</li>
                                <li><i class="bi bi-check text-warning"></i> Cocina básica</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 mb-3">
                    <div class="card border-danger h-100">
                        <div class="card-header bg-danger text-white">
                            <h6 class="mb-0">Suite Deluxe</h6>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title text-danger">€350/noche</h5>
                            <p class="card-text">Máximo lujo y confort. Jacuzzi privado, terraza panorámica y servicio de mayordomo 24h.</p>
                            <ul class="list-unstyled">
                                <li><i class="bi bi-check text-danger"></i> 4 personas</li>
                                <li><i class="bi bi-check text-danger"></i> Jacuzzi privado</li>
                                <li><i class="bi bi-check text-danger"></i> Terraza panorámica</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Datos de contacto -->
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="bi bi-geo-alt"></i> Información de Contacto</h5>
                        </div>
                        <div class="card-body">
                            <p><strong><i class="bi bi-geo-alt-fill text-info"></i> Dirección:</strong><br>
                            Avenida del Lujo, 123<br>
                            28001 Madrid, España</p>
                            
                            <p><strong><i class="bi bi-telephone-fill text-info"></i> Teléfono:</strong><br>
                            +34 91 123 45 67</p>
                            
                            <p><strong><i class="bi bi-envelope-fill text-info"></i> Email:</strong><br>
                            info@grandluxuryhotel.com</p>
                            
                            <p><strong><i class="bi bi-globe text-info"></i> Web:</strong><br>
                            www.grandluxuryhotel.com</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0"><i class="bi bi-clock-history"></i> Horarios</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>Recepción:</strong> 24 horas</p>
                            <p><strong>Check-in:</strong> Desde las 15:00</p>
                            <p><strong>Check-out:</strong> Hasta las 12:00</p>
                            <p><strong>Restaurante:</strong> 7:00 - 23:00</p>
                            <p><strong>Spa:</strong> 9:00 - 21:00</p>
                            <p><strong>Gimnasio:</strong> 6:00 - 22:00</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Mensaje final -->
            <div class="alert alert-primary mt-4">
                <h5><i class="bi bi-chat-heart"></i> Nuestra Filosofía</h5>
                <p class="mb-0">En <strong>Grand Luxury Hotel</strong> creemos que cada huésped merece una experiencia única y personalizada. Nos esforzamos por superar expectativas, ofreciendo no solo un lugar para descansar, sino un destino memorable donde cada detalle cuenta.</p>
            </div>
        </div>
        
        <div class="card-footer text-center">
            <div class="row">
                <div class="col-md-4">
                    <i class="bi bi-people display-6 text-primary"></i>
                    <h5>150+</h5>
                    <p>Huéspedes diarios</p>
                </div>
                <div class="col-md-4">
                    <i class="bi bi-door-closed display-6 text-primary"></i>
                    <h5>80</h5>
                    <p>Habitaciones disponibles</p>
                </div>
                <div class="col-md-4">
                    <i class="bi bi-star display-6 text-primary"></i>
                    <h5>25+</h5>
                    <p>Años de experiencia</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>