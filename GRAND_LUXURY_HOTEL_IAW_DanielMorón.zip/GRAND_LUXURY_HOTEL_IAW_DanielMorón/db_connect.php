<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "dml";
$password = "dml";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
  die("<div class='alert alert-danger'>Connection failed: " . mysqli_connect_error() . "</div>");
}

// INCLUIR CABECERA
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-plug"></i> Conectar a MySQL</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="bi bi-plug"></i> Conexión a MySQL</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-success">
                <i class="bi bi-check-circle me-2"></i>
                <strong>Conexión exitosa</strong> - Conectado al servidor MySQL.
            </div>
            
            <div class="card mb-3">
                <div class="card-body">
                    <h6><i class="bi bi-info-circle me-2"></i>Detalles de la conexión:</h6>
                    <table class="table table-sm">
                        <tr>
                            <td width="30%"><strong>Servidor:</strong></td>
                            <td><?php echo htmlspecialchars($servername); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Usuario:</strong></td>
                            <td><?php echo htmlspecialchars($username); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Base de datos:</strong></td>
                            <td>No seleccionada (conexión al servidor)</td>
                        </tr>
                        <tr>
                            <td><strong>Estado:</strong></td>
                            <td><span class="badge bg-success">Conectado</span></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div class="alert alert-info">
                <h6><i class="bi bi-lightbulb me-2"></i>Próximos pasos:</h6>
                <ol class="mb-0">
                    <li>Crea la base de datos del hotel</li>
                    <li>Crea las tablas necesarias</li>
                    <li>Inserta datos de ejemplo</li>
                </ol>
            </div>
            
            <div class="d-grid gap-2 d-md-flex">
                <a href="db_create.php" class="btn btn-primary">
                    <i class="bi bi-database-add me-2"></i>Crear Base de Datos
                </a>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-2"></i>Volver al Inicio
                </a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>