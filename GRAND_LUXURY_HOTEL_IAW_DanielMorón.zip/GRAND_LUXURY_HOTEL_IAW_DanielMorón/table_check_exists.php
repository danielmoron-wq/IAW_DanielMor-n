<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}
$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bbdd_dml_mockaroo";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// INCLUIR CABECERA
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-question-circle"></i> Verificar Tablas</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0"><i class="bi bi-question-circle"></i> Verificar Tablas en la Base de Datos</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                Verificando tablas en la base de datos: <strong><?php echo htmlspecialchars($dbname); ?></strong>
            </div>
            
            <?php
            // 1. Consulta para verificar todas las tablas
            $sql = "SHOW TABLES";
            $result = mysqli_query($conn, $sql);
            
            if ($result == false) {
                echo '<div class="alert alert-danger">';
                echo '<i class="bi bi-exclamation-triangle me-2"></i>';
                echo '<strong>Error en la consulta:</strong> ' . mysqli_error($conn);
                echo '</div>';
            } else {
                $num_tablas = mysqli_num_rows($result);
                
                echo '<div class="alert ' . ($num_tablas > 0 ? 'alert-success' : 'alert-warning') . '">';
                echo '<i class="bi bi-' . ($num_tablas > 0 ? 'check-circle' : 'exclamation-triangle') . ' me-2"></i>';
                echo 'Se encontraron <strong>' . $num_tablas . '</strong> tabla(s) en la base de datos.';
                echo '</div>';
                
                if ($num_tablas > 0) {
                    echo '<div class="card mb-3">';
                    echo '<div class="card-body">';
                    echo '<h6><i class="bi bi-list-check me-2"></i>Tablas encontradas:</h6>';
                    echo '<div class="table-responsive">';
                    echo '<table class="table table-sm">';
                    echo '<thead><tr><th>#</th><th>Nombre de la Tabla</th><th>Estado</th></tr></thead>';
                    echo '<tbody>';
                    
                    $counter = 1;
                    while ($row = mysqli_fetch_array($result)) {
                        $tabla = $row[0];
                        echo '<tr>';
                        echo '<td>' . $counter . '</td>';
                        echo '<td><code>' . htmlspecialchars($tabla) . '</code></td>';
                        echo '<td><span class="badge bg-success">Existe</span></td>';
                        echo '</tr>';
                        $counter++;
                    }
                    
                    echo '</tbody>';
                    echo '</table>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            }
            
            // 2. Verificar tabla específica: habitaciones
            echo '<hr class="my-4">';
            echo '<h5><i class="bi bi-door-closed me-2"></i>Verificación específica:</h5>';
            
            $tablas_a_verificar = ['habitaciones', 'reservas'];
            
            foreach ($tablas_a_verificar as $tabla) {
                $sql_check = "SHOW TABLES LIKE '$tabla'";
                $result_check = mysqli_query($conn, $sql_check);
                
                echo '<div class="mb-3">';
                echo '<div class="card">';
                echo '<div class="card-body">';
                echo '<h6 class="card-title">Tabla: <code>' . htmlspecialchars($tabla) . '</code></h6>';
                
                if (mysqli_num_rows($result_check) == 0) {
                    echo '<div class="alert alert-warning mb-0">';
                    echo '<i class="bi bi-exclamation-triangle me-2"></i>';
                    echo 'La tabla <strong>' . htmlspecialchars($tabla) . '</strong> NO existe.';
                    echo '</div>';
                    
                    // Mostrar botón para crear la tabla
                    echo '<div class="mt-2">';
                    if ($tabla == 'habitaciones') {
                        echo '<a href="table_create_rooms.php" class="btn btn-sm btn-primary">';
                        echo '<i class="bi bi-plus-circle me-1"></i>Crear tabla habitaciones';
                        echo '</a>';
                    } else {
                        echo '<a href="table_create_reservations.php" class="btn btn-sm btn-primary">';
                        echo '<i class="bi bi-plus-circle me-1"></i>Crear tabla reservas';
                        echo '</a>';
                    }
                    echo '</div>';
                } else {
                    echo '<div class="alert alert-success mb-0">';
                    echo '<i class="bi bi-check-circle me-2"></i>';
                    echo 'La tabla <strong>' . htmlspecialchars($tabla) . '</strong> existe.';
                    echo '</div>';
                }
                
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
            ?>
            
            <div class="alert alert-info">
                <h6><i class="bi bi-lightbulb me-2"></i>Recomendaciones:</h6>
                <ul class="mb-0">
                    <li>Para un funcionamiento completo, necesitas ambas tablas</li>
                    <li>Si falta alguna tabla, haz clic en el botón correspondiente para crearla</li>
                    <li>Después de crear las tablas, puedes insertar datos de ejemplo</li>
                </ul>
            </div>
            
            <div class="d-grid gap-2 d-md-flex">
                <a href="table_create_rooms.php" class="btn btn-primary">
                    <i class="bi bi-door-closed me-2"></i>Crear Tabla Habitaciones
                </a>
                <a href="table_create_reservations.php" class="btn btn-success">
                    <i class="bi bi-calendar-check me-2"></i>Crear Tabla Reservas
                </a>
                <a href="data_insert_rooms.php" class="btn btn-warning">
                    <i class="bi bi-cloud-upload me-2"></i>Insertar Datos Demo
                </a>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-house me-2"></i>Ir al Inicio
                </a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>