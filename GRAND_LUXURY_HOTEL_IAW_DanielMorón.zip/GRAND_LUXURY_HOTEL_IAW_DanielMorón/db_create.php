<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bbdd_dml_mockaroo";

// Create connection (sin base de datos)
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
  die("<div class='alert alert-danger'>Connection failed: " . mysqli_connect_error() . "</div>");
}

// INCLUIR CABECERA
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-database-add"></i> Crear Base de Datos</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-database-add"></i> Crear Base de Datos</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                Se creará la base de datos: <strong><?php echo htmlspecialchars($dbname); ?></strong>
            </div>
            
            <?php
            // Create database
            $sql = "CREATE DATABASE IF NOT EXISTS $dbname 
                    CHARACTER SET utf8mb4 
                    COLLATE utf8mb4_unicode_ci";
            
            if (mysqli_query($conn, $sql) == false) {
                echo '<div class="alert alert-danger">';
                echo '<i class="bi bi-exclamation-triangle me-2"></i>';
                echo '<strong>Error creando base de datos:</strong> ' . mysqli_error($conn);
                echo '</div>';
            } else {
                echo '<div class="alert alert-success">';
                echo '<i class="bi bi-check-circle me-2"></i>';
                echo '<strong>Base de datos creada exitosamente:</strong> ' . htmlspecialchars($dbname);
                echo '</div>';
                
                // Intentar seleccionar la base de datos para verificar
                if (mysqli_select_db($conn, $dbname)) {
                    echo '<div class="alert alert-success">';
                    echo '<i class="bi bi-check-circle me-2"></i>';
                    echo 'Base de datos seleccionada correctamente.';
                    echo '</div>';
                } else {
                    echo '<div class="alert alert-warning">';
                    echo '<i class="bi bi-exclamation-triangle me-2"></i>';
                    echo 'Base de datos creada pero no se pudo seleccionar automáticamente.';
                    echo '</div>';
                }
            }
            ?>
            
            <div class="card mb-3">
                <div class="card-body">
                    <h6><i class="bi bi-info-circle me-2"></i>Detalles de la operación:</h6>
                    <table class="table table-sm">
                        <tr>
                            <td width="30%"><strong>Base de datos:</strong></td>
                            <td><?php echo htmlspecialchars($dbname); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Charset:</strong></td>
                            <td>utf8mb4</td>
                        </tr>
                        <tr>
                            <td><strong>Collation:</strong></td>
                            <td>utf8mb4_unicode_ci</td>
                        </tr>
                        <tr>
                            <td><strong>Comando SQL:</strong></td>
                            <td><code><?php echo htmlspecialchars($sql); ?></code></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div class="alert alert-success">
                <h6><i class="bi bi-lightbulb me-2"></i>Próximos pasos:</h6>
                <ol class="mb-0">
                    <li>Crear las tablas necesarias</li>
                    <li>Insertar datos de ejemplo</li>
                    <li>Comprobar que todo funciona</li>
                </ol>
            </div>
            
            <div class="d-grid gap-2 d-md-flex">
                <a href="table_create_rooms.php" class="btn btn-success">
                    <i class="bi bi-table me-2"></i>Crear Tablas
                </a>
                <a href="db_connect.php" class="btn btn-outline-primary">
                    <i class="bi bi-arrow-left me-2"></i>Volver a Conectar
                </a>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-house me-2"></i>Ir al Inicio
                </a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>