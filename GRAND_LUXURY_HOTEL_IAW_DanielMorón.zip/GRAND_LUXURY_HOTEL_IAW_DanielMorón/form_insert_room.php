<?php
// Iniciar sesión solo una vez
session_start();

// Verificar login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Incluir archivos necesarios
require_once 'recoge.php';
require_once 'session.php';
require_once 'funciones.php';

$errores = [];
$exito = false;

// Datos del formulario
$numero = '';
$tipo = '';
$precio = '';
$capacidad = '';
$estado = 'disponible';
$descripcion = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger datos
    $numero = recoge('numero');
    $tipo = recoge('tipo');
    $precio = recoge('precio');
    $capacidad = recoge('capacidad');
    $estado = recoge('estado');
    $descripcion = recoge('descripcion');
    
    // Validaciones
    validarCampoNoVacio($numero, "Número de habitación", $errores);
    validarCampoNoVacio($tipo, "Tipo de habitación", $errores);
    validarCampoNoVacio($precio, "Precio por noche", $errores);
    validarCampoNoVacio($capacidad, "Capacidad", $errores);
    
    if (empty($errores)) {
        // Validaciones específicas
        if (!in_array($tipo, ['sencilla', 'doble', 'suite', 'deluxe'])) {
            $errores[] = "Tipo de habitación no válido.";
        }
        
        if (!in_array($estado, ['disponible', 'ocupada', 'mantenimiento', 'limpieza'])) {
            $errores[] = "Estado no válido.";
        }
        
        validarNumero($precio, 10, 1000, $errores, "Precio");
        validarNumero($capacidad, 1, 10, $errores, "Capacidad");
    }
    
    // Si no hay errores, insertar en la base de datos
    if (empty($errores)) {
        $conn = conectarBD();
        
        if ($conn) {
            // Verificar si ya existe una habitación con ese número
            $sql_check = "SELECT id FROM habitaciones WHERE numero = ?";
            $stmt_check = mysqli_prepare($conn, $sql_check);
            mysqli_stmt_bind_param($stmt_check, "s", $numero);
            mysqli_stmt_execute($stmt_check);
            mysqli_stmt_store_result($stmt_check);
            
            if (mysqli_stmt_num_rows($stmt_check) > 0) {
                $errores[] = "Ya existe una habitación con el número $numero.";
            } else {
                // Insertar nueva habitación
                $sql_insert = "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt_insert = mysqli_prepare($conn, $sql_insert);
                mysqli_stmt_bind_param($stmt_insert, "ssdiss", $numero, $tipo, $precio, $capacidad, $estado, $descripcion);
                
                if (mysqli_stmt_execute($stmt_insert)) {
                    $exito = true;
                    $id_nuevo = mysqli_insert_id($conn);
                    $mensaje_exito = "Habitación <strong>$numero</strong> añadida correctamente (ID: $id_nuevo).";
                    
                    // Limpiar formulario
                    $numero = $tipo = $precio = $capacidad = $descripcion = '';
                    $estado = 'disponible';
                } else {
                    $errores[] = "Error al insertar habitación: " . mysqli_error($conn);
                }
                
                if ($stmt_insert) {
                    mysqli_stmt_close($stmt_insert);
                }
            }
            
            if ($stmt_check) {
                mysqli_stmt_close($stmt_check);
            }
            
            mysqli_close($conn);
        } else {
            $errores[] = "Error al conectar a la base de datos.";
        }
    }
}

// Incluir cabecera
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-plus-circle"></i> Añadir Habitación</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Añadir Nueva Habitación</h5>
        </div>
        <div class="card-body">
            <?php 
            mostrarErrores($errores);
            if ($exito) {
                mostrarExito($mensaje_exito);
            }
            ?>
            
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Número de habitación -->
                    <div class="col-md-6">
                        <label for="numero" class="form-label">Número de habitación *</label>
                        <input type="text" class="form-control" id="numero" name="numero" 
                               value="<?php echo htmlspecialchars($numero); ?>"
                               required maxlength="10" placeholder="Ej: 101, 202A">
                        <div class="form-text">Identificador único de la habitación</div>
                    </div>
                    
                    <!-- Tipo de habitación -->
                    <div class="col-md-6">
                        <label for="tipo" class="form-label">Tipo de habitación *</label>
                        <select class="form-select" id="tipo" name="tipo" required>
                            <option value="">-- Seleccionar tipo --</option>
                            <option value="sencilla" <?php echo $tipo == 'sencilla' ? 'selected' : ''; ?>>Sencilla (€80/noche)</option>
                            <option value="doble" <?php echo $tipo == 'doble' ? 'selected' : ''; ?>>Doble (€120/noche)</option>
                            <option value="suite" <?php echo $tipo == 'suite' ? 'selected' : ''; ?>>Suite (€200/noche)</option>
                            <option value="deluxe" <?php echo $tipo == 'deluxe' ? 'selected' : ''; ?>>Deluxe (€350/noche)</option>
                        </select>
                        <div class="form-text">Selecciona el tipo de habitación</div>
                    </div>
                    
                    <!-- Precio -->
                    <div class="col-md-4">
                        <label for="precio" class="form-label">Precio por noche (€) *</label>
                        <input type="number" class="form-control" id="precio" name="precio" 
                               value="<?php echo htmlspecialchars($precio); ?>"
                               required min="10" max="1000" step="0.01">
                        <div class="form-text">Precio en euros por noche</div>
                    </div>
                    
                    <!-- Capacidad -->
                    <div class="col-md-4">
                        <label for="capacidad" class="form-label">Capacidad (personas) *</label>
                        <input type="number" class="form-control" id="capacidad" name="capacidad" 
                               value="<?php echo htmlspecialchars($capacidad); ?>"
                               required min="1" max="10" step="1">
                        <div class="form-text">Máximo número de personas</div>
                    </div>
                    
                    <!-- Estado -->
                    <div class="col-md-4">
                        <label for="estado" class="form-label">Estado *</label>
                        <select class="form-select" id="estado" name="estado" required>
                            <option value="disponible" <?php echo $estado == 'disponible' ? 'selected' : ''; ?>>Disponible</option>
                            <option value="ocupada" <?php echo $estado == 'ocupada' ? 'selected' : ''; ?>>Ocupada</option>
                            <option value="mantenimiento" <?php echo $estado == 'mantenimiento' ? 'selected' : ''; ?>>En mantenimiento</option>
                            <option value="limpieza" <?php echo $estado == 'limpieza' ? 'selected' : ''; ?>>En limpieza</option>
                        </select>
                        <div class="form-text">Estado actual de la habitación</div>
                    </div>
                    
                    <!-- Descripción -->
                    <div class="col-12">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" rows="3"><?php echo htmlspecialchars($descripcion); ?></textarea>
                        <div class="form-text">Información adicional sobre la habitación</div>
                    </div>
                </div>
                
                <div class="mt-4 d-grid gap-2 d-md-flex">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Guardar Habitación
                    </button>
                    <button type="reset" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-clockwise me-2"></i>Limpiar Formulario
                    </button>
                    <a href="form_search_rooms.php" class="btn btn-outline-info">
                        <i class="bi bi-search me-2"></i>Buscar Habitaciones
                    </a>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-x-circle me-2"></i>Cancelar
                    </a>
                </div>
            </form>
        </div>
        <div class="card-footer">
            <div class="alert alert-info mb-0">
                <i class="bi bi-info-circle me-2"></i>
                Los campos marcados con * son obligatorios. La habitación se registrará en el sistema inmediatamente.
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>