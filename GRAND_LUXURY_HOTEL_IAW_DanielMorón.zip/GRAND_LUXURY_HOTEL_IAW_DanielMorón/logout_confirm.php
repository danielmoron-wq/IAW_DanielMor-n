<?php
require_once 'session.php';
redirectIfNotLoggedIn();

$page_title = 'Confirmar Cierre de Sesión';
include("header.php");
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm border-warning">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0">
                        <i class="bi bi-question-circle"></i> Confirmar Cierre de Sesión
                    </h5>
                </div>
                <div class="card-body text-center py-5">
                    <div class="mb-4">
                        <i class="bi bi-door-closed text-warning" style="font-size: 4rem;"></i>
                    </div>
                    <h4>¿Estás seguro de que deseas cerrar sesión?</h4>
                    <p class="text-muted mb-4">
                        Serás redirigido a la página de login del sistema.
                    </p>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                        <a href="logout.php" class="btn btn-danger btn-lg px-4">
                            <i class="bi bi-box-arrow-right me-2"></i>Sí, Cerrar Sesión
                        </a>
                        <a href="index.php" class="btn btn-outline-secondary btn-lg px-4">
                            <i class="bi bi-x-circle me-2"></i>Cancelar
                        </a>
                    </div>
                </div>
                <div class="card-footer text-center">
                    <small class="text-muted">
                        <i class="bi bi-info-circle me-1"></i>
                        Tu sesión actual será finalizada completamente.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>