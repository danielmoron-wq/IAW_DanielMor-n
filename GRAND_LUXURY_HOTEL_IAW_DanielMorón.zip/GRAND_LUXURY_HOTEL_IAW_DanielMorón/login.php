<?php
require_once 'session.php';
redirectIfLoggedIn();

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Login simple como en tu proyecto
    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit();
    } else {
        $error = 'Usuario o contraseña incorrectos';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Solo estilos básicos para login -->
    <link rel="stylesheet" href="style.css">
    <title>Login - Grand Luxury Hotel</title>
    <style>
        .login-header h1 {
            color: #0d6efd;
        }
        .login-credentials {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
        }
    </style>
</head>
<body class="login-page">
    <div class="login-container fade-in">
        <div class="login-header">
            <h1><i class="bi bi-building"></i> Grand Luxury Hotel</h1>
            <p>Sistema de Gestión Hotelera</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group mb-3">
                <label for="username" class="form-label">Usuario:</label>
                <input type="text" id="username" name="username" required 
                       class="form-control" placeholder="admin" autocomplete="username">
            </div>
            
            <div class="form-group mb-4">
                <label for="password" class="form-label">Contraseña:</label>
                <input type="password" id="password" name="password" required 
                       class="form-control" placeholder="••••••••" autocomplete="current-password">
            </div>
            
            <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-box-arrow-in-right"></i> Iniciar Sesión
            </button>
            
            <div class="login-credentials mt-4">
                <p class="text-muted small mb-2">
                    <strong>Credenciales de acceso:</strong>
                </p>
                <div class="row">
                    <div class="col-6">
                        <p class="mb-1"><strong>Usuario:</strong></p>
                        <code>admin</code>
                    </div>
                    <div class="col-6">
                        <p class="mb-1"><strong>Contraseña:</strong></p>
                        <code>P4ssw0rd</code>
                    </div>
                </div>
            </div>
        </form>
    </div>
</body>
</html>