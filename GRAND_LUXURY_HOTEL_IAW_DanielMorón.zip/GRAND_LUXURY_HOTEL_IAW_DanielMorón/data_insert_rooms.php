<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bbdd_dml_mockaroo";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("<div style='color: red;'>Connection failed: " . mysqli_connect_error() . "</div>");
}

// INCLUIR CABECERA CON BOOTSTRAP
include("header.php");
?>

<div class="container">
    <div class="card shadow-sm">
        <div class="card-header bg-warning text-dark">
            <h5 class="mb-0"><i class="bi bi-bed"></i> Insertar Habitaciones Demo</h5>
        </div>
        <div class="card-body">
            <?php
            echo "<div class='alert alert-info'>Connected successfully</div>";
            
            // Prepare the multiple query
            $sql = "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('101', 'sencilla', 80.00, 1, 'disponible', 'Habitación sencilla con vista al jardín');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('102', 'sencilla', 80.00, 1, 'disponible', 'Habitación sencilla tranquila');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('201', 'doble', 120.00, 2, 'disponible', 'Habitación doble con cama king size');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('202', 'doble', 120.00, 2, 'ocupada', 'Habitación doble con balcón');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('203', 'doble', 120.00, 2, 'disponible', 'Habitación doble con baño moderno');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('301', 'suite', 200.00, 3, 'disponible', 'Suite con sala de estar');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('302', 'suite', 200.00, 3, 'mantenimiento', 'Suite en renovación');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('401', 'deluxe', 350.00, 4, 'disponible', 'Suite deluxe con jacuzzi');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('402', 'deluxe', 350.00, 4, 'disponible', 'Suite deluxe con terraza privada');";
            $sql .= "INSERT INTO habitaciones (numero, tipo, precio, capacidad, estado, descripcion)
            VALUES ('501', 'deluxe', 350.00, 4, 'limpieza', 'Suite deluxe presidencial')";

            if (mysqli_multi_query($conn, $sql)) {
                echo "<div class='alert alert-success'>New records created successfully<br>";
                echo "10 habitaciones demo insertadas en la base de datos.</div>";
            } else {
                echo "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
            }
            ?>
            
            <div class="table-responsive mt-3">
                <table class="table table-striped">
                    <thead class="table-dark">
                        <tr><th>Número</th><th>Tipo</th><th>Precio</th><th>Capacidad</th><th>Estado</th><th>Descripción</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $habitaciones = [
                            ['101', 'sencilla', 80.00, 1, 'disponible', 'Habitación sencilla con vista al jardín'],
                            ['102', 'sencilla', 80.00, 1, 'disponible', 'Habitación sencilla tranquila'],
                            ['201', 'doble', 120.00, 2, 'disponible', 'Habitación doble con cama king size'],
                            ['202', 'doble', 120.00, 2, 'ocupada', 'Habitación doble con balcón'],
                            ['203', 'doble', 120.00, 2, 'disponible', 'Habitación doble con baño moderno'],
                            ['301', 'suite', 200.00, 3, 'disponible', 'Suite con sala de estar'],
                            ['302', 'suite', 200.00, 3, 'mantenimiento', 'Suite en renovación'],
                            ['401', 'deluxe', 350.00, 4, 'disponible', 'Suite deluxe con jacuzzi'],
                            ['402', 'deluxe', 350.00, 4, 'disponible', 'Suite deluxe con terraza privada'],
                            ['501', 'deluxe', 350.00, 4, 'limpieza', 'Suite deluxe presidencial']
                        ];

                        foreach ($habitaciones as $h) {
                            $badge_class = '';
                            switch ($h[4]) {
                                case 'disponible': $badge_class = 'bg-success'; break;
                                case 'ocupada': $badge_class = 'bg-danger'; break;
                                case 'mantenimiento': $badge_class = 'bg-warning'; break;
                                case 'limpieza': $badge_class = 'bg-info'; break;
                            }
                            
                            echo "<tr>";
                            echo "<td>" . $h[0] . "</td>";
                            echo "<td>" . $h[1] . "</td>";
                            echo "<td>€" . $h[2] . "</td>";
                            echo "<td>" . $h[3] . "</td>";
                            echo "<td><span class='badge $badge_class'>" . $h[4] . "</span></td>";
                            echo "<td>" . $h[5] . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <div class="d-grid gap-2 d-md-flex mt-3">
                <a href="index.php" class="btn btn-primary">Volver al Inicio</a>
                <a href="data_insert_reservations.php" class="btn btn-success">Insertar Reservas Demo</a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>