<?php
// Iniciar sesión solo una vez
session_start();

// Verificar login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Incluir archivos necesarios - IMPORTANTE: session.php debe estar antes
require_once 'config.php';  // Primero config
require_once 'session.php'; // Luego session que usa config
require_once 'funciones.php'; // Finalmente funciones

// Verificar si la función conectarBD existe
if (!function_exists('conectarBD')) {
    die("<div class='alert alert-danger'>Error: La función conectarBD() no está definida.</div>");
}

$conn = conectarBD();

if (!$conn) {
    die("<div class='alert alert-danger'>Error al conectar a la base de datos.</div>");
}

// Consulta para obtener todas las reservas con información de la habitación
$sql = "SELECT r.*, h.numero as numero_habitacion, h.tipo, h.precio as precio_noche 
        FROM reservas r 
        JOIN habitaciones h ON r.habitacion_id = h.id 
        ORDER BY r.fecha_entrada DESC";
$result = mysqli_query($conn, $sql);

include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-list-check"></i> Ver Reservas</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="bi bi-list-check"></i> Todas las Reservas</h5>
        </div>
        <div class="card-body">
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle me-2"></i>
                    Se encontraron <strong><?php echo mysqli_num_rows($result); ?></strong> reservas en el sistema.
                </div>
                
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Código</th>
                                <th>Cliente</th>
                                <th>Contacto</th>
                                <th>Habitación</th>
                                <th>Fechas</th>
                                <th>Noches</th>
                                <th>Total</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result)): 
                                $badge_class = '';
                                switch ($row['estado']) {
                                    case 'confirmada': $badge_class = 'bg-success'; break;
                                    case 'pendiente': $badge_class = 'bg-warning text-dark'; break;
                                    case 'cancelada': $badge_class = 'bg-danger'; break;
                                    case 'completada': $badge_class = 'bg-info'; break;
                                }
                                
                                // Calcular diferencia de días para ver si la reserva está activa
                                $hoy = new DateTime();
                                $entrada = new DateTime($row['fecha_entrada']);
                                $salida = new DateTime($row['fecha_salida']);
                                $es_reserva_activa = ($hoy >= $entrada && $hoy <= $salida);
                            ?>
                                <tr <?php echo $es_reserva_activa ? 'class="table-primary"' : ''; ?>>
                                    <td>
                                        <code><?php echo htmlspecialchars($row['codigo_reserva']); ?></code>
                                        <?php if ($es_reserva_activa): ?>
                                            <span class="badge bg-primary ms-1">ACTIVA</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($row['cliente_nombre']); ?></strong>
                                    </td>
                                    <td>
                                        <small>
                                            <?php echo htmlspecialchars($row['cliente_email']); ?><br>
                                            <?php echo htmlspecialchars($row['cliente_telefono'] ?? 'N/A'); ?>
                                        </small>
                                    </td>
                                    <td>
                                        Hab. <?php echo htmlspecialchars($row['numero_habitacion']); ?><br>
                                        <small class="text-muted"><?php echo htmlspecialchars(ucfirst($row['tipo'])); ?></small>
                                    </td>
                                    <td>
                                        <small>
                                            <i class="bi bi-box-arrow-in-right"></i> <?php echo date('d/m/Y', strtotime($row['fecha_entrada'])); ?><br>
                                            <i class="bi bi-box-arrow-right"></i> <?php echo date('d/m/Y', strtotime($row['fecha_salida'])); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($row['noches']); ?> noches<br>
                                        <small class="text-muted">€<?php echo number_format($row['precio_noche'], 2); ?>/noche</small>
                                    </td>
                                    <td class="text-success fw-bold">
                                        €<?php echo number_format($row['precio_total'], 2); ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars(ucfirst($row['estado'])); ?></span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="form_update_reservation.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-outline-primary" title="Modificar">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="form_delete_reservation.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-outline-danger" title="Cancelar"
                                               onclick="return confirm('¿Cancelar reserva <?php echo htmlspecialchars($row['codigo_reserva']); ?>?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Estadísticas -->
                <?php 
                mysqli_data_seek($result, 0);
                $total_reservas = mysqli_num_rows($result);
                $total_ingresos = 0;
                $reservas_confirmadas = 0;
                $reservas_pendientes = 0;
                
                while ($row = mysqli_fetch_assoc($result)) {
                    $total_ingresos += $row['precio_total'];
                    if ($row['estado'] == 'confirmada') $reservas_confirmadas++;
                    if ($row['estado'] == 'pendiente') $reservas_pendientes++;
                }
                ?>
                
                <div class="row mt-4">
                    <div class="col-md-4">
                        <div class="card bg-light border-0">
                            <div class="card-body text-center">
                                <h5 class="card-title text-success">€<?php echo number_format($total_ingresos, 2); ?></h5>
                                <p class="card-text small">Total ingresos</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-light border-0">
                            <div class="card-body text-center">
                                <h5 class="card-title text-primary"><?php echo $total_reservas; ?></h5>
                                <p class="card-text small">Total reservas</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-light border-0">
                            <div class="card-body text-center">
                                <h5 class="card-title text-warning"><?php echo $reservas_pendientes; ?></h5>
                                <p class="card-text small">Pendientes</p>
                            </div>
                        </div>
                    </div>
                </div>
                
            <?php else: ?>
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    No hay reservas registradas en el sistema.
                </div>
                
                <div class="alert alert-info">
                    <h6><i class="bi bi-lightbulb me-2"></i>¿Cómo empezar?</h6>
                    <ul class="mb-0">
                        <li>Primero inserta habitaciones de ejemplo</li>
                        <li>Luego inserta reservas de ejemplo</li>
                        <li>O añade reservas manualmente</li>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="mt-4 d-grid gap-2 d-md-flex">
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-2"></i>Volver al Inicio
                </a>
            </div>
        </div>
    </div>
</div>

<?php
if ($result) mysqli_free_result($result);
mysqli_close($conn);
include("footer.php");
?>