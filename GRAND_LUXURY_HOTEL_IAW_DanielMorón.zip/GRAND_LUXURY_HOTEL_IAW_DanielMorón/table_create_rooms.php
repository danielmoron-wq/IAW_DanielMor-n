<?php
// AÑADIR SESSION_START Y VERIFICAR LOGIN
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bbdd_dml_mockaroo";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("<div class='alert alert-danger'>Connection failed: " . mysqli_connect_error() . "</div>");
}

// INCLUIR CABECERA
include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-table"></i> Crear Tabla Habitaciones</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-table"></i> Crear Tabla: Habitaciones</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                Se creará la tabla <strong>habitaciones</strong> en la base de datos <strong><?php echo htmlspecialchars($dbname); ?></strong>
            </div>
            
            <?php
            // sql to create table
            $sql = "CREATE TABLE IF NOT EXISTS habitaciones (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                numero VARCHAR(10) NOT NULL UNIQUE,
                tipo ENUM('sencilla', 'doble', 'suite', 'deluxe') NOT NULL,
                precio DECIMAL(10,2) NOT NULL,
                capacidad INT NOT NULL,
                estado ENUM('disponible', 'ocupada', 'mantenimiento', 'limpieza') DEFAULT 'disponible',
                descripcion TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )";

            if (mysqli_query($conn, $sql) == false) {
                echo '<div class="alert alert-danger">';
                echo '<i class="bi bi-exclamation-triangle me-2"></i>';
                echo '<strong>Error creando tabla:</strong> ' . mysqli_error($conn);
                echo '</div>';
            } else {
                echo '<div class="alert alert-success">';
                echo '<i class="bi bi-check-circle me-2"></i>';
                echo '<strong>Tabla creada exitosamente:</strong> habitaciones';
                echo '</div>';
            }
            ?>
            
            <div class="card mb-3">
                <div class="card-body">
                    <h6><i class="bi bi-columns me-2"></i>Estructura de la tabla:</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Campo</th>
                                    <th>Tipo</th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><code>id</code></td>
                                    <td>INT AUTO_INCREMENT</td>
                                    <td>Identificador único</td>
                                </tr>
                                <tr>
                                    <td><code>numero</code></td>
                                    <td>VARCHAR(10)</td>
                                    <td>Número de habitación (único)</td>
                                </tr>
                                <tr>
                                    <td><code>tipo</code></td>
                                    <td>ENUM</td>
                                    <td>sencilla, doble, suite, deluxe</td>
                                </tr>
                                <tr>
                                    <td><code>precio</code></td>
                                    <td>DECIMAL(10,2)</td>
                                    <td>Precio por noche (€)</td>
                                </tr>
                                <tr>
                                    <td><code>capacidad</code></td>
                                    <td>INT</td>
                                    <td>Personas máximas</td>
                                </tr>
                                <tr>
                                    <td><code>estado</code></td>
                                    <td>ENUM</td>
                                    <td>disponible, ocupada, mantenimiento, limpieza</td>
                                </tr>
                                <tr>
                                    <td><code>descripcion</code></td>
                                    <td>TEXT</td>
                                    <td>Descripción adicional</td>
                                </tr>
                                <tr>
                                    <td><code>created_at</code></td>
                                    <td>TIMESTAMP</td>
                                    <td>Fecha de creación</td>
                                </tr>
                                <tr>
                                    <td><code>updated_at</code></td>
                                    <td>TIMESTAMP</td>
                                    <td>Última actualización</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="alert alert-success">
                <h6><i class="bi bi-lightbulb me-2"></i>Próximos pasos:</h6>
                <ol class="mb-0">
                    <li>Crear la tabla de reservas</li>
                    <li>Insertar datos de ejemplo</li>
                    <li>Comprobar que las tablas existen</li>
                </ol>
            </div>
            
            <div class="d-grid gap-2 d-md-flex">
                <a href="table_create_reservations.php" class="btn btn-success">
                    <i class="bi bi-table me-2"></i>Crear Tabla Reservas
                </a>
                <a href="data_insert_rooms.php" class="btn btn-warning">
                    <i class="bi bi-cloud-upload me-2"></i>Insertar Datos Demo
                </a>
                <a href="table_check_exists.php" class="btn btn-outline-info">
                    <i class="bi bi-question-circle me-2"></i>Verificar Tablas
                </a>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="bi bi-house me-2"></i>Ir al Inicio
                </a>
            </div>
        </div>
    </div>
</div>

<?php
// Close connection
mysqli_close($conn);

include("footer.php");
?>