<?php
// Iniciar sesión solo una vez
session_start();

// Verificar login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Incluir archivos necesarios
require_once 'recoge.php';
require_once 'session.php';
require_once 'funciones.php';

$errores = [];
$resultados = [];
$tipo = recoge('tipo');
$estado = recoge('estado');
$precio_min = recoge('precio_min');
$precio_max = recoge('precio_max');
$mostrar_resultados = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = conectarBD();
    
    if ($conn) {
        // Construir consulta dinámica
        $sql = "SELECT * FROM habitaciones WHERE 1=1";
        $params = [];
        $types = "";
        
        if (!empty($tipo)) {
            $sql .= " AND tipo = ?";
            $params[] = $tipo;
            $types .= "s";
        }
        
        if (!empty($estado)) {
            $sql .= " AND estado = ?";
            $params[] = $estado;
            $types .= "s";
        }
        
        if (!empty($precio_min) && is_numeric($precio_min)) {
            $sql .= " AND precio >= ?";
            $params[] = $precio_min;
            $types .= "d";
        }
        
        if (!empty($precio_max) && is_numeric($precio_max)) {
            $sql .= " AND precio <= ?";
            $params[] = $precio_max;
            $types .= "d";
        }
        
        $sql .= " ORDER BY precio ASC";
        
        // Preparar y ejecutar consulta
        if (!empty($params)) {
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, $types, ...$params);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if ($result) {
                $resultados = mysqli_fetch_all($result, MYSQLI_ASSOC);
                $mostrar_resultados = true;
            } else {
                $errores[] = "Error en la consulta: " . mysqli_error($conn);
            }
            
            if ($stmt) {
                mysqli_stmt_close($stmt);
            }
        } else {
            // Si no hay filtros, mostrar todas
            $result = mysqli_query($conn, "SELECT * FROM habitaciones ORDER BY precio ASC");
            if ($result) {
                $resultados = mysqli_fetch_all($result, MYSQLI_ASSOC);
                $mostrar_resultados = true;
            } else {
                $errores[] = "Error en la consulta: " . mysqli_error($conn);
            }
        }
        
        mysqli_close($conn);
    } else {
        $errores[] = "Error al conectar a la base de datos.";
    }
}

include("header.php");
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="bi bi-house"></i> Inicio</a></li>
            <li class="breadcrumb-item active"><i class="bi bi-search"></i> Buscar Habitaciones</li>
        </ol>
    </nav>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-search"></i> Buscar Habitaciones</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <?php mostrarErrores($errores); ?>
                
                <div class="row g-3">
                    <!-- Tipo de habitación -->
                    <div class="col-md-4">
                        <label for="tipo" class="form-label">Tipo de habitación</label>
                        <select class="form-select" id="tipo" name="tipo">
                            <option value="">Todos los tipos</option>
                            <option value="sencilla" <?php echo $tipo == 'sencilla' ? 'selected' : ''; ?>>Sencilla</option>
                            <option value="doble" <?php echo $tipo == 'doble' ? 'selected' : ''; ?>>Doble</option>
                            <option value="suite" <?php echo $tipo == 'suite' ? 'selected' : ''; ?>>Suite</option>
                            <option value="deluxe" <?php echo $tipo == 'deluxe' ? 'selected' : ''; ?>>Deluxe</option>
                        </select>
                    </div>
                    
                    <!-- Estado -->
                    <div class="col-md-4">
                        <label for="estado" class="form-label">Estado</label>
                        <select class="form-select" id="estado" name="estado">
                            <option value="">Todos los estados</option>
                            <option value="disponible" <?php echo $estado == 'disponible' ? 'selected' : ''; ?>>Disponible</option>
                            <option value="ocupada" <?php echo $estado == 'ocupada' ? 'selected' : ''; ?>>Ocupada</option>
                            <option value="mantenimiento" <?php echo $estado == 'mantenimiento' ? 'selected' : ''; ?>>Mantenimiento</option>
                            <option value="limpieza" <?php echo $estado == 'limpieza' ? 'selected' : ''; ?>>Limpieza</option>
                        </select>
                    </div>
                    
                    <!-- Rango de precios -->
                    <div class="col-md-4">
                        <label for="precio_min" class="form-label">Precio mínimo (€)</label>
                        <input type="number" class="form-control" id="precio_min" name="precio_min" 
                               value="<?php echo htmlspecialchars($precio_min); ?>"
                               min="0" step="10">
                    </div>
                    
                    <div class="col-md-4">
                        <label for="precio_max" class="form-label">Precio máximo (€)</label>
                        <input type="number" class="form-control" id="precio_max" name="precio_max" 
                               value="<?php echo htmlspecialchars($precio_max); ?>"
                               min="0" step="10">
                    </div>
                </div>
                
                <div class="mt-4 d-grid gap-2 d-md-flex">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search me-2"></i> Buscar Habitaciones
                    </button>
                    <button type="reset" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-clockwise me-2"></i> Limpiar Filtros
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-2"></i> Volver
                    </a>
                </div>
            </form>
            
            <?php if ($mostrar_resultados): ?>
                <hr class="my-4">
                <h5 class="mb-3">
                    <i class="bi bi-list-check"></i> Resultados de la búsqueda
                    <span class="badge bg-primary ms-2"><?php echo count($resultados); ?> encontradas</span>
                </h5>
                
                <?php if (empty($resultados)): ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> No se encontraron habitaciones con los criterios seleccionados.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Número</th>
                                    <th>Tipo</th>
                                    <th>Precio/noche</th>
                                    <th>Capacidad</th>
                                    <th>Estado</th>
                                    <th>Descripción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($resultados as $habitacion): 
                                    $badge_class = '';
                                    switch ($habitacion['estado']) {
                                        case 'disponible': $badge_class = 'bg-success'; break;
                                        case 'ocupada': $badge_class = 'bg-danger'; break;
                                        case 'mantenimiento': $badge_class = 'bg-warning text-dark'; break;
                                        case 'limpieza': $badge_class = 'bg-info'; break;
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($habitacion['id']); ?></td>
                                        <td><strong><?php echo htmlspecialchars($habitacion['numero']); ?></strong></td>
                                        <td><?php echo htmlspecialchars(ucfirst($habitacion['tipo'])); ?></td>
                                        <td class="text-success fw-bold">€<?php echo number_format($habitacion['precio'], 2); ?></td>
                                        <td><?php echo htmlspecialchars($habitacion['capacidad']); ?> persona(s)</td>
                                        <td><span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($habitacion['estado']); ?></span></td>
                                        <td><small><?php echo htmlspecialchars($habitacion['descripcion'] ?? '-'); ?></small></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle"></i> 
                        Total de habitaciones: <?php echo count($resultados); ?> | 
                        Precio promedio: €<?php 
                            $total = 0;
                            foreach ($resultados as $h) $total += $h['precio'];
                            echo number_format(count($resultados) > 0 ? $total / count($resultados) : 0, 2);
                        ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>