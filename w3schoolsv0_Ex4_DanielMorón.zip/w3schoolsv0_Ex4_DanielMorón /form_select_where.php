<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$resultados = [];
$lastname = recoge('lastname');
$mostrar_resultados = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar campo lastname
    validarCampoNoVacio($lastname, "Apellido", $errores);
    
    if (empty($errores)) {
        $conn = conectarBD();
        
        $sql = "SELECT id, firstname, lastname, email, telefono, codigousuario 
                FROM MyGuests 
                WHERE lastname = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $lastname);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if ($result) {
            $resultados = mysqli_fetch_all($result, MYSQLI_ASSOC);
            $mostrar_resultados = true;
        } else {
            $errores[] = "Error en la consulta: " . mysqli_error($conn);
        }
        
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar por Apellido - Sistema de Gestión</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>🔍 Buscar por Apellido</h1>
            <div class="user-info">
                <a href="index.php" class="btn-secondary">🏠 Volver al Inicio</a>
            </div>
        </header>
        
        <main>
            <div class="form-container">
                <form method="POST" action="">
                    <?php 
                    include("funciones.php");
                    mostrarErrores($errores); 
                    ?>
                    
                    <div class="form-group">
                        <label for="lastname">Apellido a buscar *</label>
                        <input type="text" id="lastname" name="lastname" 
                               value="<?php echo htmlspecialchars($lastname); ?>"
                               required minlength="2" maxlength="30">
                        <small>Introduce el apellido que deseas buscar</small>
                    </div>
                    
                    <div class="form-buttons">
                        <button type="submit" class="btn-primary">🔍 Buscar</button>
                    </div>
                </form>
                
                <?php if ($mostrar_resultados): ?>
                    <div class="results-container">
                        <h3>📊 Resultados para "<?php echo htmlspecialchars($lastname); ?>"</h3>
                        
                        <?php if (empty($resultados)): ?>
                            <?php mostrarInfo('No se encontraron registros con el apellido "' . htmlspecialchars($lastname) . '".'); ?>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nombre</th>
                                            <th>Apellido</th>
                                            <th>Email</th>
                                            <th>Teléfono</th>
                                            <th>Código Usuario</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($resultados as $row): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['firstname']); ?></td>
                                                <td><?php echo htmlspecialchars($row['lastname']); ?></td>
                                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                                <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                                                <td><?php echo htmlspecialchars($row['codigousuario']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <p class="results-count">
                                Se encontraron <?php echo count($resultados); ?> registro(s).
                            </p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>