<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$exito = false;
$id = recoge('id');
$confirmado = recoge('confirmado') === 'si';

if ($_SERVER["REQUEST_METHOD"] == "POST" && $confirmado) {
    // Validar ID
    validarID($id, $errores);
    
    if (empty($errores)) {
        $conn = conectarBD();
        
        // Primero verificar si existe el registro
        $sql_check = "SELECT id, firstname, lastname FROM MyGuests WHERE id = ?";
        $stmt_check = mysqli_prepare($conn, $sql_check);
        mysqli_stmt_bind_param($stmt_check, "i", $id);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);
        
        if (mysqli_stmt_num_rows($stmt_check) == 0) {
            $errores[] = "No existe ningún registro con el ID $id.";
        } else {
            // Obtener información del registro
            mysqli_stmt_bind_result($stmt_check, $id_reg, $firstname, $lastname);
            mysqli_stmt_fetch($stmt_check);
            
            // Proceder a eliminar
            $sql_delete = "DELETE FROM MyGuests WHERE id = ?";
            $stmt_delete = mysqli_prepare($conn, $sql_delete);
            mysqli_stmt_bind_param($stmt_delete, "i", $id);
            
            if (mysqli_stmt_execute($stmt_delete)) {
                if (mysqli_affected_rows($conn) > 0) {
                    $exito = true;
                    $mensaje_exito = "Registro eliminado correctamente: $firstname $lastname (ID: $id)";
                    $id = ''; // Limpiar el campo
                }
            } else {
                $errores[] = "Error al eliminar registro: " . mysqli_error($conn);
            }
            
            mysqli_stmt_close($stmt_delete);
        }
        
        mysqli_stmt_close($stmt_check);
        mysqli_close($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Registro - Sistema de Gestión</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>🗑️ Eliminar Registro</h1>
            <div class="user-info">
                <a href="index.php" class="btn-secondary">🏠 Volver al Inicio</a>
            </div>
        </header>
        
        <main>
            <div class="form-container">
                <?php 
                include("funciones.php");
                mostrarErrores($errores);
                if ($exito) {
                    mostrarExito($mensaje_exito);
                }
                ?>
                
                <?php if (!$confirmado): ?>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="id">ID del registro a eliminar *</label>
                            <input type="number" id="id" name="id" 
                                   value="<?php echo htmlspecialchars($id); ?>"
                                   required min="1" step="1">
                            <small>Introduce el ID numérico del registro que deseas eliminar</small>
                        </div>
                        
                        <div class="form-buttons">
                            <button type="submit" name="confirmado" value="si" 
                                    class="btn-danger" onclick="return confirm('¿Estás seguro de eliminar este registro? Esta acción no se puede deshacer.')">
                                🗑️ Eliminar Registro
                            </button>
                            <a href="index.php" class="btn-secondary">Cancelar</a>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="form-buttons">
                        <a href="form_delete.php" class="btn-primary">Eliminar otro registro</a>
                        <a href="index.php" class="btn-secondary">Volver al inicio</a>
                    </div>
                <?php endif; ?>
                
                <div class="form-info alert alert-warning">
                    <h3>⚠️ Advertencia</h3>
                    <p>Esta acción eliminará permanentemente el registro de la base de datos.</p>
                    <p>No se podrá recuperar la información una vez eliminada.</p>
                </div>
            </div>
        </main>
    </div>
</body>
</html>