<?php
session_start();

// Credenciales del administrador
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'P4ssw0rd');

// Credenciales de base de datos
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'dml');
define('DB_PASSWORD', 'dml');
define('DB_NAME', 'bd_w3_dml2');

function isLoggedIn() {
    return isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        header("Location: index.php");
        exit();
    }
}

function logout() {
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

// Validar campos no vacíos
function validarCampoNoVacio($campo, $nombreCampo, &$errores) {
    if (empty($campo)) {
        $errores[] = "El campo '$nombreCampo' es obligatorio.";
        return false;
    }
    return true;
}

// Validar email
function validarEmail($email, &$errores) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El formato del email no es válido.";
        return false;
    }
    return true;
}

// Validar código usuario (formato: u + 5 dígitos)
function validarCodigoUsuario($codigo, &$errores) {
    if (!preg_match('/^u\d{5}$/', $codigo)) {
        $errores[] = "El código de usuario debe tener el formato 'u' seguido de 5 dígitos (ej: u12345).";
        return false;
    }
    return true;
}

// Validar teléfono (9 dígitos)
function validarTelefono($telefono, &$errores) {
    if (!preg_match('/^\d{9}$/', $telefono)) {
        $errores[] = "El teléfono debe tener exactamente 9 dígitos.";
        return false;
    }
    return true;
}

// Validar ID (número entero positivo)
function validarID($id, &$errores) {
    if (!ctype_digit($id) || $id <= 0) {
        $errores[] = "El ID debe ser un número entero positivo.";
        return false;
    }
    return true;
}

// Conectar a la base de datos
function conectarBD() {
    $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    
    if (!$conn) {
        die("Error de conexión: " . mysqli_connect_error());
    }
    
    mysqli_set_charset($conn, "utf8");
    return $conn;
}
?>