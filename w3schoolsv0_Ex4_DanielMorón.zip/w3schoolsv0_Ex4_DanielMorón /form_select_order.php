<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$resultados = [];

// Obtener valor de order_by - usar solo un parámetro o cadena vacía como segundo
$order_by_raw = recoge('order_by'); // Solo un parámetro (el segundo será "" por defecto)
$order_by = in_array($order_by_raw, ['ASC', 'DESC']) ? $order_by_raw : 'ASC';

$mostrar_resultados = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = conectarBD();
    
    $sql = "SELECT id, firstname, lastname, email, telefono, codigousuario 
            FROM MyGuests 
            ORDER BY lastname $order_by, firstname $order_by";
    
    $result = mysqli_query($conn, $sql);
    
    if ($result) {
        $resultados = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $mostrar_resultados = true;
    } else {
        $errores[] = "Error en la consulta: " . mysqli_error($conn);
    }
    
    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Ordenados - Sistema de Gestión</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>📈 Visualizar Registros Ordenados</h1>
            <div class="user-info">
                <a href="index.php" class="btn-secondary">🏠 Volver al Inicio</a>
            </div>
        </header>
        
        <main>
            <div class="form-container">
                <form method="POST" action="">
                    <?php 
                    include("funciones.php");
                    mostrarErrores($errores); 
                    ?>
                    
                    <div class="form-group">
                        <label for="order_by">Ordenar por:</label>
                        <select id="order_by" name="order_by" class="form-select">
                            <option value="ASC" <?php echo $order_by === 'ASC' ? 'selected' : ''; ?>>
                                Ascendente (A-Z)
                            </option>
                            <option value="DESC" <?php echo $order_by === 'DESC' ? 'selected' : ''; ?>>
                                Descendente (Z-A)
                            </option>
                        </select>
                        <small>Se ordenará por apellido y luego por nombre</small>
                    </div>
                    
                    <div class="form-buttons">
                        <button type="submit" class="btn-primary">📊 Mostrar Registros</button>
                    </div>
                </form>
                
                <?php if ($mostrar_resultados): ?>
                    <div class="results-container">
                        <h3>📊 Registros ordenados 
                            <?php echo $order_by === 'ASC' ? 'ascendentemente' : 'descendentemente'; ?>
                        </h3>
                        
                        <?php if (empty($resultados)): ?>
                            <?php mostrarInfo('No hay registros en la base de datos.'); ?>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nombre</th>
                                            <th>Apellido</th>
                                            <th>Email</th>
                                            <th>Teléfono</th>
                                            <th>Código Usuario</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($resultados as $row): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                                <td><?php echo htmlspecialchars($row['firstname']); ?></td>
                                                <td><?php echo htmlspecialchars($row['lastname']); ?></td>
                                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                                <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                                                <td><?php echo htmlspecialchars($row['codigousuario']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <p class="results-count">
                                Total de registros: <?php echo count($resultados); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>