<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$exito = false;
$datos = [
    'firstname' => '',
    'lastname' => '',
    'email' => '',
    'telefono' => '',
    'codigousuario' => ''
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger y validar datos usando la función recoge() de recoge.php
    $firstname = recoge('firstname');
    $lastname = recoge('lastname');
    $email = recoge('email');
    $telefono = recoge('telefono');
    $codigousuario = recoge('codigousuario');
    
    // Validaciones
    validarCampoNoVacio($firstname, "Nombre", $errores);
    validarCampoNoVacio($lastname, "Apellido", $errores);
    validarCampoNoVacio($email, "Email", $errores);
    validarEmail($email, $errores);
    validarCampoNoVacio($telefono, "Teléfono", $errores);
    validarTelefono($telefono, $errores);
    validarCampoNoVacio($codigousuario, "Código de Usuario", $errores);
    validarCodigoUsuario($codigousuario, $errores);
    
    // Guardar datos para rellenar formulario
    $datos = [
        'firstname' => $firstname,
        'lastname' => $lastname,
        'email' => $email,
        'telefono' => $telefono,
        'codigousuario' => $codigousuario
    ];
    
    // Si no hay errores, insertar en BD
    if (empty($errores)) {
        $conn = conectarBD();
        
        $sql = "INSERT INTO MyGuests (firstname, lastname, email, telefono, codigousuario) 
                VALUES (?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssss", $firstname, $lastname, $email, $telefono, $codigousuario);
        
        if (mysqli_stmt_execute($stmt)) {
            $exito = true;
            $last_id = mysqli_insert_id($conn);
            $mensaje_exito = "Registro insertado correctamente. ID: " . $last_id;
            
            // Limpiar datos del formulario
            $datos = [
                'firstname' => '',
                'lastname' => '',
                'email' => '',
                'telefono' => '',
                'codigousuario' => ''
            ];
        } else {
            $errores[] = "Error al insertar registro: " . mysqli_error($conn);
        }
        
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertar Registro - Sistema de Gestión</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>➕ Insertar Nuevo Registro</h1>
            <div class="user-info">
                <a href="index.php" class="btn-secondary">🏠 Volver al Inicio</a>
            </div>
        </header>
        
        <main>
            <div class="form-container">
                <form method="POST" action="">
                    <?php
                    // Incluir funciones para mostrar mensajes
                    include("funciones.php");
                    mostrarErrores($errores);
                    if ($exito) {
                        mostrarExito($mensaje_exito);
                    }
                    ?>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="firstname">Nombre *</label>
                            <input type="text" id="firstname" name="firstname" 
                                   value="<?php echo htmlspecialchars($datos['firstname']); ?>"
                                   required minlength="2" maxlength="30">
                            <small>Mínimo 2 caracteres</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="lastname">Apellido *</label>
                            <input type="text" id="lastname" name="lastname" 
                                   value="<?php echo htmlspecialchars($datos['lastname']); ?>"
                                   required minlength="2" maxlength="30">
                            <small>Mínimo 2 caracteres</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($datos['email']); ?>"
                                   required>
                            <small>Formato válido: usuario@dominio.com</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="telefono">Teléfono *</label>
                            <input type="text" id="telefono" name="telefono" 
                                   value="<?php echo htmlspecialchars($datos['telefono']); ?>"
                                   required pattern="\d{9}" 
                                   title="9 dígitos sin espacios">
                            <small>9 dígitos (ej: 612345678)</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="codigousuario">Código Usuario *</label>
                            <input type="text" id="codigousuario" name="codigousuario" 
                                   value="<?php echo htmlspecialchars($datos['codigousuario']); ?>"
                                   required pattern="u\d{5}" 
                                   title="'u' seguido de 5 dígitos">
                            <small>Formato: u + 5 dígitos (ej: u12345)</small>
                        </div>
                    </div>
                    
                    <div class="form-buttons">
                        <button type="submit" class="btn-primary">💾 Insertar Registro</button>
                        <button type="reset" class="btn-secondary">🔄 Limpiar Formulario</button>
                    </div>
                </form>
                
                <div class="form-info">
                    <h3>📋 Información del Formulario</h3>
                    <p>Todos los campos marcados con * son obligatorios.</p>
                    <p>El sistema validará los datos tanto en el navegador como en el servidor.</p>
                </div>
            </div>
        </main>
    </div>
</body>
</html>