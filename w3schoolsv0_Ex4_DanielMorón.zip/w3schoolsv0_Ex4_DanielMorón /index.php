<?php
require_once 'session.php';
redirectIfNotLoggedIn();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestión de Base de Datos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>📊 Sistema de Gestión de Base de Datos</h1>
            <div class="user-info">
                <p>Usuario: <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'admin'); ?></strong></p>
                <button onclick="showLogoutConfirmation()" class="btn-logout">🚪 Cerrar Sesión</button>
            </div>
        </header>
        
        <main>
            <h2>🔧 Operaciones Disponibles</h2>
            
            <div class="operations-grid">
                <!-- NUEVO: SECCIÓN DE FORMULARIOS -->
                <div class="operation-category">
                    <h3>📝 Formularios Interactivos</h3>
                    <ol>
                        <li><a href="form_insert.php">➕ Insertar nuevo registro</a></li>
                        <li><a href="form_select_where.php">🔍 Buscar por apellido</a></li>
                        <li><a href="form_select_order.php">📈 Visualizar ordenados</a></li>
                        <li><a href="form_delete.php">🗑️ Eliminar registro por ID</a></li>
                        <li><a href="form_update.php">✏️ Actualizar apellido por ID</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>📁 Base de Datos</h3>
                    <ol start="6">
                        <li><a href="db_connect.php">Conectar</a></li>
                        <li><a href="db_create.php">Crear la base de datos</a></li>
                        <li><a href="db_drop.php">Borrar la base de datos</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>📊 Tablas</h3>
                    <ol start="9">
                        <li><a href="table_create_guests.php">Crear tabla MyGuests</a></li>
                        <li><a href="table_check_exists.php">Verificar existencia de tabla</a></li>
                        <li><a href="table_drop.php">Borrar tabla MyGuests</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>➕ Insertar Datos (Directo)</h3>
                    <ol start="12">
                        <li><a href="data_insert_single.php">Insertar datos (registro único)</a></li>
                        <li><a href="data_insert_single_get_last_id.php">Insertar y obtener último ID</a></li>
                        <li><a href="data_insert_multiple_simple.php">Insertar múltiples datos (simple)</a></li>
                        <li><a href="data_insert_multiple_prepared.php">Insertar múltiples datos (preparado)</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>👁️ Consultar Datos (Directo)</h3>
                    <ol start="16">
                        <li><a href="data_count.php">Contar registros</a></li>
                        <li><a href="data_select_all.php">Visualizar todos los datos</a></li>
                        <li><a href="data_select_where.php">Visualizar datos (WHERE)</a></li>
                        <li><a href="data_select_orderby.php">Visualizar datos (ORDER BY)</a></li>
                        <li><a href="data_select_where_orderby_html_table.php">Visualizar en tabla HTML</a></li>
                    </ol>
                </div>
                
                <div class="operation-category">
                    <h3>✏️ Modificar Datos (Directo)</h3>
                    <ol start="21">
                        <li><a href="data_delete.php">Borrar usuario id=3</a></li>
                        <li><a href="data_update.php">Actualizar usuario id=2</a></li>
                    </ol>
                </div>
            </div>
            
            <div class="info-box">
                <h3>ℹ️ Información del Sistema</h3>