<?php
require_once 'session.php';
include("recoge.php");
redirectIfNotLoggedIn();

$errores = [];
$exito = false;
$id = recoge('id');
$new_lastname = recoge('new_lastname');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validaciones
    validarID($id, $errores);
    validarCampoNoVacio($new_lastname, "Nuevo apellido", $errores);
    
    if (empty($errores)) {
        $conn = conectarBD();
        
        // Primero verificar si existe el registro
        $sql_check = "SELECT firstname, lastname FROM MyGuests WHERE id = ?";
        $stmt_check = mysqli_prepare($conn, $sql_check);
        mysqli_stmt_bind_param($stmt_check, "i", $id);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);
        
        if (mysqli_stmt_num_rows($stmt_check) == 0) {
            $errores[] = "No existe ningún registro con el ID $id.";
        } else {
            // Obtener información actual
            mysqli_stmt_bind_result($stmt_check, $current_firstname, $current_lastname);
            mysqli_stmt_fetch($stmt_check);
            
            // Proceder a actualizar
            $sql_update = "UPDATE MyGuests SET lastname = ? WHERE id = ?";
            $stmt_update = mysqli_prepare($conn, $sql_update);
            mysqli_stmt_bind_param($stmt_update, "si", $new_lastname, $id);
            
            if (mysqli_stmt_execute($stmt_update)) {
                if (mysqli_affected_rows($conn) > 0) {
                    $exito = true;
                    $mensaje_exito = "Registro actualizado correctamente:<br>";
                    $mensaje_exito .= "ID: $id<br>";
                    $mensaje_exito .= "Nombre: $current_firstname<br>";
                    $mensaje_exito .= "Apellido anterior: $current_lastname<br>";
                    $mensaje_exito .= "Apellido nuevo: $new_lastname";
                    
                    // Limpiar campos
                    $id = '';
                    $new_lastname = '';
                } else {
                    $errores[] = "No se realizaron cambios (posiblemente el nuevo apellido es igual al anterior).";
                }
            } else {
                $errores[] = "Error al actualizar registro: " . mysqli_error($conn);
            }
            
            mysqli_stmt_close($stmt_update);
        }
        
        mysqli_stmt_close($stmt_check);
        mysqli_close($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Apellido - Sistema de Gestión</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>✏️ Actualizar Apellido</h1>
            <div class="user-info">
                <a href="index.php" class="btn-secondary">🏠 Volver al Inicio</a>
            </div>
        </header>
        
        <main>
            <div class="form-container">
                <form method="POST" action="">
                    <?php 
                    include("funciones.php");
                    mostrarErrores($errores);
                    if ($exito) {
                        mostrarExito($mensaje_exito);
                    }
                    ?>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="id">ID del registro *</label>
                            <input type="number" id="id" name="id" 
                                   value="<?php echo htmlspecialchars($id); ?>"
                                   required min="1" step="1">
                            <small>ID numérico del registro a actualizar</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_lastname">Nuevo apellido *</label>
                            <input type="text" id="new_lastname" name="new_lastname" 
                                   value="<?php echo htmlspecialchars($new_lastname); ?>"
                                   required minlength="2" maxlength="30">
                            <small>Introduce el nuevo apellido (2-30 caracteres)</small>
                        </div>
                    </div>
                    
                    <div class="form-buttons">
                        <button type="submit" class="btn-primary">✏️ Actualizar Apellido</button>
                        <button type="reset" class="btn-secondary">🔄 Limpiar</button>
                    </div>
                </form>
                
                <div class="form-info">
                    <h3>ℹ️ Información</h3>
                    <p>Este formulario actualizará únicamente el apellido del registro especificado.</p>
                    <p>Se mantendrán todos los demás campos sin cambios.</p>
                </div>
            </div>
        </main>
    </div>
</body>
</html>