<?php
$servername = "localhost";
$username = "dml";
$password = "dml";
$dbname = "bd_w3_dml2";

// Create connection (procedural)
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully<br>";
// Prepare statement
$stmt = mysqli_prepare($conn, "INSERT INTO MyGuests (firstname, lastname, email, telefono, codigousuario) VALUES (?, ?, ?, ?, ?)");

// Bind parameters
mysqli_stmt_bind_param($stmt, "sssss", $firstname, $lastname, $email, $telefono, $codigousuario);

// Set parameters and execute first record
$firstname = "John";
$lastname = "Doe";
$email = "john@example.com";
$telefono = "698547320";
$codigousuario = "u97416";
mysqli_stmt_execute($stmt);

// Second record
$firstname = "Mary";
$lastname = "Moe";
$email = "mary@example.com";
$telefono = "6510322870";
$codigousuario = "u44160";
mysqli_stmt_execute($stmt);

// Third record
$firstname = "Julie";
$lastname = "Dooley";
$email = "julie@example.com";
$telefono = "607882981";
$codigousuario = "u10647";
mysqli_stmt_execute($stmt);

echo "New records created successfully";

// Close statement and connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>

