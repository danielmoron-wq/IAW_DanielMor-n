<?php
require_once 'session.php';
logout();
header("Location: login.php");
exit();
?>